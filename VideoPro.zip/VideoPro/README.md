# Video Pro
Offline video editor for Android (Jetpack Compose + Media3 Transformer).
Built by the GitHub Actions workflow `video-release.yml`, which injects the app name, icon, version and
`assets/config.json` (features, max quality, watermark) from the portal's Video Pro admin page.
Features: multi-clip timeline, trim, split, speed, mute, rotate/flip, filters + colour, text, music, aspect ratios, 720p/1080p export, watermark.
