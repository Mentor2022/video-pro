# Video Pro
Offline video editor for Android (Jetpack Compose + Media3 Transformer).
Built by the GitHub Actions workflow `video-release.yml`, which injects the app name, icon, version and
`assets/config.json` (features, max quality, watermark) from the portal's Video Pro admin page.
Features: multi-clip timeline, trim, split, speed, mute, rotate/flip, filters + colour, text, music, aspect ratios, 720p/1080p export, watermark.
Also: photos as clips (length 1-15 s), per-clip / music / voice-over volume, crop (1:1, 16:9, 9:16, 4:5), text fonts, duplicate clip, undo / redo, stickers, voice-over, saved projects.
New options reuse the existing admin features: crop is part of "rotate", volume sliders part of "volume", fonts part of "text"; photos, undo and duplicate are always on.
Fade in / out per clip (dip-to-black transition). Exports are saved to the gallery (Movies/VideoPro); Android 9 and older ask for storage permission first.
Background removal for photos (offline, ML Kit selfie segmentation bundled in the app, about 5 MB) with a plain colour behind the person; ready-made Looks (Cinematic, Vlog, Retro, Film B&W, Dreamy, Clean). Both sit under the existing "filters" admin feature.
