# Video Pro
Offline video editor for Android (Jetpack Compose + Media3 Transformer).
Built by the GitHub Actions workflow `video-release.yml`, which injects the app name, icon, version and
`assets/config.json` (features, max quality, watermark) from the portal's Video Pro admin page.
Features: multi-clip timeline, trim, split, speed, mute, rotate/flip, filters + colour, text, music, aspect ratios, 720p/1080p export, watermark.
Also: photos as clips (length 1-15 s), per-clip / music / voice-over volume, crop (1:1, 16:9, 9:16, 4:5), text fonts, duplicate clip, undo / redo, stickers, voice-over, saved projects.
New options reuse the existing admin features: crop is part of "rotate", volume sliders part of "volume", fonts part of "text"; photos, undo and duplicate are always on.
Fade in / out per clip (dip-to-black transition). Exports are saved to the gallery (Movies/VideoPro); Android 9 and older ask for storage permission first.
Background removal for photos (offline, ML Kit selfie segmentation bundled in the app, about 5 MB) with a plain colour behind the person; ready-made Looks (Cinematic, Vlog, Retro, Film B&W, Dreamy, Clean). Both sit under the existing "filters" admin feature.
Typing captions: text that types itself letter by letter (Text tab > Add typing caption, or the Typing chip on any text).
Auto-captions: offline speech to text (Vosk, English). The speech model is added to app/src/main/assets/model-en by the build workflow (video-release.yml step "Download speech model"); without it the app shows that captions are unavailable. Captions can be edited with Edit words.
Effects tab (CapCut-style, per clip, with an Intensity slider, part of the "filters" admin feature): Motion (Zoom in/out, Pulse, Heartbeat, Shake, Swing, Drift), Flash (Flash, Strobe, Flicker, Glitch, Disco), Colour (Glow, Invert, Night vision, Duotone) and Retro (Sepia, Old film, VHS). They are drawn in the finished video, like fades. The tab row and the preview height now adapt so tabs and panels no longer overlap on small screens.
Transitions (Effects tab > Transition to the next clip): Flash cut, Zoom punch, Whip, Glitch cut, Dip to white, Dip to black, about 0.7 s around the cut. Text animations (Text tab, per text): Pop, Slide up, Fade, Bounce. Both show in the exported video, not in the preview.
