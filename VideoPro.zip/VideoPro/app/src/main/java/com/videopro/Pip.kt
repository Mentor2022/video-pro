package com.videopro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings

/** Opens a photo the right way up and not larger than maxSide. */
fun decodeUpright(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
    return try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return null
        val orientation = try {
            ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
        } catch (e: Exception) { null } ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (m.isIdentity) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    } catch (e: Exception) {
        null
    }
}

/**
 * A small video or photo on top of the main video (picture-in-picture).
 * For a video, a picture is taken from the file for every export frame (about 15 per second).
 * Call close() when the export is over.
 */
class PipOverlay(private val ctx: Context, private val item: PipItem, private val outW: Int, private val outH: Int) : BitmapOverlay() {
    private val tw: Int
    private val th: Int
    private var retriever: MediaMetadataRetriever? = null
    private var last: Bitmap? = null
    private var lastQ = -1L
    private var blank: Bitmap? = null

    init {
        var w = (outW * item.size.fraction).toInt().coerceAtLeast(32)
        var h = (w * item.displayH.toFloat() / item.displayW.coerceAtLeast(1)).toInt().coerceAtLeast(32)
        val maxH = (outH * 0.7f).toInt()
        if (h > maxH) { w = (w * maxH.toFloat() / h).toInt(); h = maxH }
        tw = ((w / 2) * 2).coerceAtLeast(32)
        th = ((h / 2) * 2).coerceAtLeast(32)
    }

    private fun blankCard(): Bitmap = blank ?: Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888).also { blank = it }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val local = (ms - item.startMs).coerceIn(0L, item.lengthMs)
        return try { frameAt(if (item.isImage) 0L else local) } catch (e: Throwable) { blankCard() }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = presentationTimeUs / 1000
        val on = ms >= item.startMs && ms <= item.startMs + item.lengthMs
        val halfW = tw.toFloat() / outW
        val halfH = th.toFloat() / outH
        val mx = 0.04f
        val my = mx * outW / outH
        val ax = item.pos.ax * (1f - halfW - mx)
        val ay = item.pos.ay * (1f - halfH - my)
        return OverlaySettings.Builder().setBackgroundFrameAnchor(ax, ay).setAlphaScale(if (on) 1f else 0f).build()
    }

    private fun frameAt(t: Long): Bitmap {
        val q = if (item.isImage) 0L else (t / 66L) * 66L
        val cached = last
        if (cached != null && q == lastQ) return cached
        val raw: Bitmap? = if (item.isImage) decodeUpright(ctx, item.uri, 1280) else grab(q)
        val out = if (raw == null) blankCard() else card(raw)
        last = out
        lastQ = q
        return out
    }

    private fun grab(q: Long): Bitmap? {
        val r = retriever ?: MediaMetadataRetriever().also { it.setDataSource(ctx, item.uri); retriever = it }
        val us = q * 1000L
        return if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, tw, th)
        else r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST)
    }

    /** Rounded corners and a thin white border. */
    private fun card(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val radius = minOf(tw, th) * 0.08f
        val rect = RectF(0f, 0f, tw.toFloat(), th.toFloat())
        val path = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(path)
        c.drawBitmap(src, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = minOf(tw, th) * 0.025f }
        val inset = border.strokeWidth / 2f
        c.drawRoundRect(RectF(inset, inset, tw - inset, th - inset), radius, radius, border)
        if (src !== out) src.recycle()
        return out
    }

    fun close() {
        try { retriever?.release() } catch (e: Exception) { /* ignore */ }
        retriever = null
    }
}
