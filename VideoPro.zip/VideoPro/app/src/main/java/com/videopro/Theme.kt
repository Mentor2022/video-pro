package com.videopro

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF0F0B1E)
    val Panel = Color(0xFF1B1530)
    val Panel2 = Color(0xFF261E42)
    val Violet = Color(0xFF7C3AED)
    val Pink = Color(0xFFF472B6)
    val Cyan = Color(0xFF22D3EE)
    val Amber = Color(0xFFFBBF24)
    val Text = Color(0xFFF5F3FF)
    val Muted = Color(0xFFA8A1C7)
}

@Composable
fun VideoProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Violet, onPrimary = Color.White, secondary = Pal.Pink, tertiary = Pal.Cyan,
            background = Pal.Bg, surface = Pal.Panel, onBackground = Pal.Text, onSurface = Pal.Text,
            surfaceVariant = Pal.Panel2, onSurfaceVariant = Pal.Muted,
        ),
        content = content,
    )
}
