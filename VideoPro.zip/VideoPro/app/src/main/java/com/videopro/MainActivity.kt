@file:OptIn(ExperimentalMaterial3Api::class)

package com.videopro

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        setContent {
            VideoProTheme {
                val vm: EditorViewModel = viewModel()
                Surface(color = Pal.Bg, modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                    if (vm.clips.isEmpty()) Home(vm) else Editor(vm)
                }
            }
        }
    }
}

/** The same system font the exported video uses, so the preview looks like the result. */
fun TextFont.composeFamily(): FontFamily = FontFamily(android.graphics.Typeface.create(family, android.graphics.Typeface.NORMAL))

// ───────────────────────── small building blocks ─────────────────────────

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .clip(shape)
            .then(if (selected) Modifier.background(Brush.horizontalGradient(listOf(Pal.Violet, Pal.Pink))) else Modifier.background(Pal.Panel2))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (selected) Color.White else Pal.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ToolButton(emoji: String, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Pal.Panel2)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .width(58.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 20.sp, color = if (enabled) Color.White else Pal.Muted)
        Text(label, fontSize = 11.sp, color = if (enabled) Pal.Text else Pal.Muted, maxLines = 1)
    }
}

@Composable
fun GradientButton(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (enabled) Brush.horizontalGradient(listOf(Pal.Violet, Pal.Pink)) else Brush.horizontalGradient(listOf(Pal.Panel2, Pal.Panel2)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Pal.Panel).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Pal.Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        content()
    }
}

// ───────────────────────── home ─────────────────────────

@Composable
fun Home(vm: EditorViewModel) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addClips(it) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3B1D8F), Pal.Bg)))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier.size(112.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pal.Violet, Pal.Pink))),
            contentAlignment = Alignment.Center,
        ) { Text("🎬", fontSize = 52.sp) }
        Spacer(Modifier.height(22.dp))
        Text(stringResource(R.string.app_name), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("Edit videos and photos on your phone.\nNo internet needed. Your files stay with you.", color = Pal.Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(30.dp))
        GradientButton("＋  New project", onClick = { pick.launch(arrayOf("video/*", "image/*")) })
        LaunchedEffect(Unit) { vm.refreshProjects() }
        if (vm.projects.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("YOUR PROJECTS", color = Pal.Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Column(modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (pr in vm.projects) {
                    var ask by remember(pr.id) { mutableStateOf(false) }
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.Panel).clickable { vm.openProject(pr) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(pr.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(pr.clipCount.toString() + (if (pr.clipCount == 1) " clip · " else " clips · ") + formatTime(pr.durationMs), color = Pal.Muted, fontSize = 12.sp)
                        }
                        TextButton(onClick = { ask = true }) { Text("🗑", fontSize = 18.sp) }
                    }
                    if (ask) {
                        AlertDialog(
                            onDismissRequest = { ask = false },
                            title = { Text("Delete this project?") },
                            text = { Text("Your original videos are not touched.") },
                            confirmButton = { TextButton(onClick = { ask = false; vm.deleteProject(pr.id) }) { Text("Delete") } },
                            dismissButton = { TextButton(onClick = { ask = false }) { Text("Cancel") } },
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        val feats = listOf("trim" to "✂️ Trim", "speed" to "⚡ Speed", "filters" to "🎨 Filters", "text" to "🔤 Text", "music" to "🎵 Music", "ratio" to "📐 Ratios").filter { AppConfig.has(it.first) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (f in feats.take(3)) Chip(f.second, false) {}
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (f in feats.drop(3)) Chip(f.second, false) {}
        }
    }
}

// ───────────────────────── editor ─────────────────────────

/** True while a voice-over is recorded, so the preview does not leak into the microphone. */
@Volatile private var silencePreview = false

private fun applyPlaybackSettings(player: ExoPlayer, clips: List<Clip>) {
    val c = clips.getOrNull(player.currentMediaItemIndex) ?: return
    player.playbackParameters = PlaybackParameters(c.speed)
    player.volume = if (c.muted || silencePreview) 0f else c.volume.coerceIn(0f, 1f) // the preview cannot be louder than 100%
}

private fun projectTime(player: ExoPlayer, clips: List<Clip>): Long {
    val idx = player.currentMediaItemIndex
    val cur = clips.getOrNull(idx) ?: return 0L
    val before = clips.take(idx).sumOf { it.effectiveMs }
    return before + (player.currentPosition.coerceAtLeast(0) / cur.speed).toLong()
}

private fun seekProject(player: ExoPlayer, clips: List<Clip>, t: Long) {
    var acc = 0L
    for ((i, c) in clips.withIndex()) {
        val len = c.effectiveMs
        if (t < acc + len || i == clips.lastIndex) {
            val pos = ((t - acc).coerceAtLeast(0) * c.speed).toLong().coerceIn(0L, c.endMs - c.startMs)
            player.seekTo(i, pos)
            applyPlaybackSettings(player, clips)
            return
        }
        acc += len
    }
}

@Composable
fun Editor(vm: EditorViewModel) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var playing by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableStateOf("edit") }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { applyPlaybackSettings(player, vm.clips) }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    // Rebuild the preview when clips are added, removed, reordered or trimmed
    val structure = vm.clips.map { Triple(it.id, it.startMs, it.endMs) }
    LaunchedEffect(structure) {
        val items = vm.clips.map { c ->
            if (c.isImage) return@map MediaItem.Builder().setUri(c.uri)
                .setMimeType(ctx.contentResolver.getType(c.uri) ?: MimeTypes.IMAGE_JPEG)
                .setImageDurationMs(c.effectiveMs)
                .build()
            MediaItem.Builder().setUri(c.uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build())
                .build()
        }
        val idx = player.currentMediaItemIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        val pos = if (player.mediaItemCount == items.size) player.currentPosition else 0L
        player.setMediaItems(items, idx, pos)
        player.prepare()
        applyPlaybackSettings(player, vm.clips)
    }
    val settings = vm.clips.map { listOf<Any>(it.id, it.speed, it.muted, it.volume) }
    LaunchedEffect(settings) { applyPlaybackSettings(player, vm.clips) }

    LaunchedEffect(player) {
        while (true) {
            if (!dragging) vm.playhead = projectTime(player, vm.clips)
            delay(100)
        }
    }

    // Projects save themselves a moment after every change
    LaunchedEffect(vm.clips, vm.texts, vm.music, vm.voice, vm.ratio, vm.quality) {
        delay(800)
        vm.saveProject()
    }
    DisposableEffect(Unit) { onDispose { silencePreview = false } }

    val addClips = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addClips(it) }
    val total = vm.totalMs

    Column(modifier = Modifier.fillMaxSize().background(Pal.Bg)) {
        // top bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("🎬 " + stringResource(R.string.app_name), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.undo() }, enabled = vm.canUndo) { Text("↶", fontSize = 22.sp, color = if (vm.canUndo) Color.White else Pal.Muted) }
            TextButton(onClick = { vm.redo() }, enabled = vm.canRedo) { Text("↷", fontSize = 22.sp, color = if (vm.canRedo) Color.White else Pal.Muted) }
            TextButton(onClick = { player.pause(); vm.newProject() }) { Text("Save & close", color = Pal.Pink) }
        }

        // preview
        Box(modifier = Modifier.fillMaxWidth().height(220.dp).background(Color.Black), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { useController = false; this.player = player } },
                modifier = Modifier.fillMaxSize(),
            )
            for (t in vm.texts) {
                if (AppConfig.has("text") && vm.playhead >= t.startMs && vm.playhead <= t.endMs) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        contentAlignment = when (t.pos) { TextPos.TOP -> Alignment.TopCenter; TextPos.CENTER -> Alignment.Center; TextPos.BOTTOM -> Alignment.BottomCenter },
                    ) { Text(t.text, color = Color(t.color), fontSize = t.size.previewSp.sp, fontFamily = t.font.composeFamily(), fontWeight = if (t.bold) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center) }
                }
            }
        }

        // play controls
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = { if (player.isPlaying) player.pause() else { if (vm.playhead >= total - 100) seekProject(player, vm.clips, 0); player.play() } }) {
                Text(if (playing) "⏸" else "▶", fontSize = 24.sp, color = Color.White)
            }
            Text(formatTime(vm.playhead) + " / " + formatTime(total), color = Pal.Muted, fontSize = 12.sp)
            Slider(
                value = vm.playhead.toFloat().coerceIn(0f, total.toFloat().coerceAtLeast(1f)),
                onValueChange = { dragging = true; vm.playhead = it.toLong(); seekProject(player, vm.clips, it.toLong()) },
                onValueChangeFinished = { dragging = false },
                valueRange = 0f..total.toFloat().coerceAtLeast(1f),
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
        }

        // clip strip
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(vm.clips, key = { it.id }) { c ->
                val thumb by produceState<android.graphics.Bitmap?>(null, c.uri, c.startMs) {
                    value = withContext(Dispatchers.IO) { vm.thumbnail(c) }
                }
                val sel = c.id == vm.selectedId
                Box(
                    modifier = Modifier
                        .size(width = 92.dp, height = 62.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Pal.Panel2)
                        .border(BorderStroke(if (sel) 3.dp else 0.dp, if (sel) Pal.Pink else Color.Transparent), RoundedCornerShape(12.dp))
                        .clickable {
                            vm.selectedId = c.id
                            val before = vm.clips.takeWhile { it.id != c.id }.sumOf { it.effectiveMs }
                            seekProject(player, vm.clips, before)
                            vm.playhead = before
                        },
                ) {
                    val b = thumb
                    if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Text(
                        formatTime(c.effectiveMs) + (if (c.speed != 1f) " ⚡" else "") + (if (c.isImage) " 🖼" else ""),
                        color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.BottomEnd).background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
            }
            item {
                Box(
                    modifier = Modifier.size(width = 62.dp, height = 62.dp).clip(RoundedCornerShape(12.dp)).background(Pal.Panel2)
                        .clickable { addClips.launch(arrayOf("video/*", "image/*")) },
                    contentAlignment = Alignment.Center,
                ) { Text("＋", color = Pal.Pink, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
            }
        }

        // tabs
        val tabs = buildList {
            add("edit" to "✂️ Edit")
            if (AppConfig.has("filters")) add("looks" to "✨ Looks")
            if (AppConfig.has("text")) add("text" to "🔤 Text")
            if (AppConfig.has("music")) add("music" to "🎵 Music")
            add("export" to "📤 Export")
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) { for ((k, label) in tabs) Chip(label, tab == k) { tab = k } }

        // panel
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (tab) {
                "looks" -> LooksPanel(vm)
                "text" -> TextPanel(vm)
                "music" -> MusicPanel(vm, player)
                "export" -> ExportPanel(vm)
                else -> EditPanel(vm, player)
            }
        }
    }
}

// ───────────────────────── edit panel ─────────────────────────

@Composable
fun EditPanel(vm: EditorViewModel, player: ExoPlayer) {
    val c = vm.selected
    if (c == null) {
        Text("Tap a clip above to edit it.", color = Pal.Muted)
        return
    }
    Section("CLIP") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
            if (AppConfig.has("trim")) ToolButton("✂️", "Split") { vm.split(vm.playhead) }
            ToolButton("◀", "Earlier", vm.clips.indexOfFirst { it.id == c.id } > 0) { vm.move(c.id, -1) }
            ToolButton("▶", "Later", vm.clips.indexOfFirst { it.id == c.id } < vm.clips.size - 1) { vm.move(c.id, 1) }
            ToolButton("⧉", "Copy") { vm.duplicate(c.id) }
            if (AppConfig.has("volume") && !c.isImage) ToolButton(if (c.muted) "🔇" else "🔊", if (c.muted) "Unmute" else "Mute") { vm.update(c.id) { it.copy(muted = !it.muted) } }
            if (AppConfig.has("rotate")) {
                ToolButton("⟳", "Rotate") { vm.update(c.id) { it.copy(rotate = (it.rotate + 90) % 360) } }
                ToolButton("⇋", "Flip") { vm.update(c.id) { it.copy(flip = !it.flip) } }
            }
            ToolButton("🗑", "Delete") { player.pause(); vm.delete(c.id) }
        }
    }

    if (c.isImage) {
        var secs by remember(c.id, c.startMs, c.endMs) { mutableStateOf((c.endMs - c.startMs) / 1000f) }
        Section("PHOTO LENGTH  " + "%.1f".format(secs) + " s") {
            Slider(
                value = secs,
                onValueChange = { secs = it },
                onValueChangeFinished = { vm.update(c.id) { x -> x.copy(endMs = x.startMs + (secs * 1000f).toLong()) } },
                valueRange = 1f..15f,
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
            )
        }
    }

    if (c.isImage && AppConfig.has("filters")) {
        Section("BACKGROUND") {
            Text("Replaces everything behind a person with a plain colour. Works offline and best on photos of people.", color = Pal.Muted, fontSize = 12.sp)
            if (vm.busy) {
                Text("Working… this takes a few seconds.", color = Pal.Pink, fontWeight = FontWeight.SemiBold)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                    for ((label, argb) in listOf("Green" to 0xFF00B140.toInt(), "White" to 0xFFFFFFFF.toInt(), "Black" to 0xFF000000.toInt(), "Blue" to 0xFF2563EB.toInt(), "Pink" to 0xFFF472B6.toInt()))
                        Chip(label, false) { vm.removeBackground(c.id, argb) }
                    if (c.originalUri != null) Chip("Restore photo", true) { vm.restoreOriginal(c.id) }
                }
            }
        }
    }

    if (AppConfig.has("trim") && !c.isImage) {
        var range by remember(c.id, c.startMs, c.endMs) { mutableStateOf(c.startMs.toFloat()..c.endMs.toFloat()) }
        Section("TRIM  " + formatTime(range.start.toLong()) + " – " + formatTime(range.endInclusive.toLong())) {
            RangeSlider(
                value = range,
                onValueChange = { r ->
                    var s = r.start
                    var e = r.endInclusive
                    if (e - s < 500f) { if (s != range.start) s = e - 500f else e = s + 500f }
                    range = s.coerceAtLeast(0f)..e.coerceAtMost(c.durationMs.toFloat())
                },
                onValueChangeFinished = { vm.update(c.id) { it.copy(startMs = range.start.toLong(), endMs = range.endInclusive.toLong()) } },
                valueRange = 0f..c.durationMs.toFloat(),
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
            )
        }
    }

    if (AppConfig.has("volume") && !c.isImage) {
        Section("VOLUME  " + (c.volume * 100).toInt() + "%") {
            LabeledSlider("Loudness", c.volume, 0f, 2f) { v -> vm.update(c.id) { it.copy(volume = v) } }
            Text("Above 100% is only heard in the finished video.", color = Pal.Muted, fontSize = 11.sp)
        }
    }

    if (AppConfig.has("filters")) {
        Section("FADE  (transition to black)") {
            Text("Fade in", color = Pal.Text, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for ((label, ms) in listOf("None" to 0L, "0.5 s" to 500L, "1 s" to 1000L)) Chip(label, c.fadeInMs == ms) { vm.update(c.id) { it.copy(fadeInMs = ms) } }
            }
            Text("Fade out", color = Pal.Text, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for ((label, ms) in listOf("None" to 0L, "0.5 s" to 500L, "1 s" to 1000L)) Chip(label, c.fadeOutMs == ms) { vm.update(c.id) { it.copy(fadeOutMs = ms) } }
            }
            Text("Fade out on one clip and fade in on the next gives a smooth dip-to-black between them. Shown in the finished video, not the preview.", color = Pal.Muted, fontSize = 11.sp)
        }
    }

    if (AppConfig.has("rotate")) {
        Section("CROP") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (m in CropMode.values()) Chip(m.label, c.crop == m) { vm.update(c.id) { it.copy(crop = m) } }
            }
            Text("Keeps the middle of the picture. It shows in the finished video, not in the preview.", color = Pal.Muted, fontSize = 11.sp)
        }
    }

    if (AppConfig.has("speed") && !c.isImage) {
        Section("SPEED") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (s in listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 3f)) Chip(if (s == 1f) "Normal" else "${s}x", c.speed == s) { vm.update(c.id) { it.copy(speed = s) } }
            }
        }
    }

    if (AppConfig.has("filters")) {
        Section("FILTER") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (f in Filter.values()) Chip(f.label, c.filter == f) { vm.update(c.id) { it.copy(filter = f) } }
            }
            Text("Filters and colours appear in the finished video. The preview above shows the original.", color = Pal.Muted, fontSize = 11.sp)
        }
        Section("COLOUR") {
            LabeledSlider("Brightness", c.brightness, -0.5f, 0.5f) { v -> vm.update(c.id) { it.copy(brightness = v) } }
            LabeledSlider("Contrast", c.contrast, -0.5f, 0.5f) { v -> vm.update(c.id) { it.copy(contrast = v) } }
            LabeledSlider("Saturation", c.saturation, -1f, 1f) { v -> vm.update(c.id) { it.copy(saturation = v) } }
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.width(88.dp))
        Slider(
            value = value, onValueChange = onChange, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Cyan, inactiveTrackColor = Pal.Panel2),
            modifier = Modifier.weight(1f),
        )
    }
}

// ───────────────────────── looks panel ─────────────────────────

@Composable
fun LooksPanel(vm: EditorViewModel) {
    Section("READY-MADE LOOKS") {
        Text("One tap sets the colours, the shape and the fades for the whole video. You can still change everything afterwards, and Undo brings your old settings back.", color = Pal.Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
            for (l in LOOKS) ToolButton(l.emoji, l.name) { vm.applyLook(l) }
        }
        Text("Looks show in the finished video, not in the preview.", color = Pal.Muted, fontSize = 11.sp)
    }
}

// ───────────────────────── text panel ─────────────────────────

@Composable
fun TextPanel(vm: EditorViewModel) {
    var dialog by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    GradientButton("＋  Add text at " + formatTime(vm.playhead), modifier = Modifier.fillMaxWidth()) { draft = ""; dialog = true }
    Section("STICKERS") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
            for (e in listOf("😂", "😍", "🔥", "👍", "❤️", "🎉", "⭐", "💯", "😎", "🙌", "😭", "👏", "🚀", "✨", "💥", "🎬")) {
                Box(
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Pal.Panel2).clickable { vm.addSticker(e, vm.playhead) }.padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(e, fontSize = 26.sp) }
            }
        }
        Text("Tap a sticker to put it on the video at the playhead. Change its time, size and place below.", color = Pal.Muted, fontSize = 11.sp)
    }
    if (vm.texts.isEmpty()) Text("Move the playhead to where the text should start, then add it.", color = Pal.Muted, fontSize = 13.sp)
    for (t in vm.texts) {
        var range by remember(t.id, t.startMs, t.endMs) { mutableStateOf(t.startMs.toFloat()..t.endMs.toFloat()) }
        Section("“" + t.text + "”") {
            Text("Shown from " + formatTime(range.start.toLong()) + " to " + formatTime(range.endInclusive.toLong()), color = Pal.Muted, fontSize = 12.sp)
            val max = vm.totalMs.toFloat().coerceAtLeast(1000f)
            RangeSlider(
                value = range.start.coerceIn(0f, max)..range.endInclusive.coerceIn(0f, max),
                onValueChange = { r -> range = r },
                onValueChangeFinished = { vm.updateText(t.id) { it.copy(startMs = range.start.toLong(), endMs = range.endInclusive.toLong()) } },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                for (col in listOf(0xFFFFFFFF, 0xFFFBBF24, 0xFFF472B6, 0xFF22D3EE, 0xFF000000)) {
                    val argb = col.toInt()
                    Box(
                        modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(argb))
                            .border(BorderStroke(if (t.color == argb) 3.dp else 1.dp, if (t.color == argb) Pal.Pink else Pal.Muted), CircleShape)
                            .clickable { vm.updateText(t.id) { it.copy(color = argb) } },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (s in TextSize.values()) Chip(s.label, t.size == s) { vm.updateText(t.id) { it.copy(size = s) } }
                for (p in TextPos.values()) Chip(p.label, t.pos == p) { vm.updateText(t.id) { it.copy(pos = p) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (f in TextFont.values()) Chip(f.label, t.font == f) { vm.updateText(t.id) { it.copy(font = f) } }
                Chip("Bold", t.bold) { vm.updateText(t.id) { it.copy(bold = !it.bold) } }
            }
            TextButton(onClick = { vm.removeText(t.id) }) { Text("🗑 Remove this text", color = Pal.Pink) }
        }
    }
    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Text on video") },
            text = { OutlinedTextField(value = draft, onValueChange = { draft = it.take(80) }, placeholder = { Text("Type your text") }) },
            confirmButton = { TextButton(onClick = { vm.addText(draft, vm.playhead); dialog = false }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Cancel") } },
        )
    }
}

// ───────────────────────── music panel ─────────────────────────

@Composable
fun MusicPanel(vm: EditorViewModel, player: ExoPlayer) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.setMusic(u) }
    val m = vm.music
    if (m == null) {
        GradientButton("🎵  Choose music from your phone", modifier = Modifier.fillMaxWidth()) { pick.launch(arrayOf("audio/*")) }
        Text("Use only music you have the right to use.", color = Pal.Muted, fontSize = 12.sp)
    } else {
        Section("MUSIC") {
            Text(m.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("Length " + formatTime(m.durationMs) + ". It is cut to the length of your video and plays together with the video's own sound. Mute clips to hear only the music.", color = Pal.Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Change", false) { pick.launch(arrayOf("audio/*")) }
                Chip("Remove", false) { vm.music = null }
            }
            LabeledSlider("Volume", m.volume, 0f, 2f) { x -> vm.music = m.copy(volume = x) }
            Text("The preview above does not play the music. It is added when you export.", color = Pal.Muted, fontSize = 11.sp)
        }
    }
    VoicePanel(vm, player)
}

@Composable
fun VoicePanel(vm: EditorViewModel, player: ExoPlayer) {
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginVoice(vm, player)
    }
    val ctx = LocalContext.current
    val v = vm.voice
    Section("VOICE-OVER") {
        if (vm.recording) {
            Text("● Recording… talk while you watch. Tap Stop when you are done.", color = Pal.Pink, fontWeight = FontWeight.SemiBold)
            GradientButton("⏹  Stop", modifier = Modifier.fillMaxWidth()) { endVoice(vm, player) }
        } else {
            if (v != null) Text("Voice-over recorded: " + formatTime(v.durationMs), color = Color.White)
            Text("Recording starts from the beginning of your video and the preview plays silently so only your voice is recorded. Use headphones for the best result.", color = Pal.Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(if (v == null) "🎙 Record" else "🎙 Record again", true) {
                    if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) beginVoice(vm, player)
                    else perm.launch(Manifest.permission.RECORD_AUDIO)
                }
                if (v != null) Chip("Remove", false) { vm.voice = null }
            }
            if (v != null) LabeledSlider("Volume", v.volume, 0f, 2f) { x -> vm.voice = v.copy(volume = x) }
            if (v != null) Text("The voice-over is mixed in when you export. The preview does not play it back.", color = Pal.Muted, fontSize = 11.sp)
        }
    }
}

private fun beginVoice(vm: EditorViewModel, player: ExoPlayer) {
    if (vm.clips.isEmpty()) return
    silencePreview = true
    seekProject(player, vm.clips, 0)
    applyPlaybackSettings(player, vm.clips)
    if (vm.startRecording()) player.play() else silencePreview = false
}

private fun endVoice(vm: EditorViewModel, player: ExoPlayer) {
    vm.stopRecording()
    player.pause()
    silencePreview = false
    applyPlaybackSettings(player, vm.clips)
}

// ───────────────────────── export panel ─────────────────────────

@Composable
fun ExportPanel(vm: EditorViewModel) {
    val ctx = LocalContext.current
    val st = vm.exportState
    // Android 9 and older need this permission to save into the gallery
    val needsPerm = android.os.Build.VERSION.SDK_INT < 29
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> vm.export() }
    val startExport = {
        if (needsPerm && androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else vm.export()
    }
    if (AppConfig.has("ratio")) {
        Section("SHAPE") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (r in Ratio.values()) Chip(r.label, vm.ratio == r) { vm.ratio = r }
            }
            Text("9:16 for TikTok, Reels and Shorts. 16:9 for YouTube. 1:1 and 4:5 for Instagram posts.", color = Pal.Muted, fontSize = 11.sp)
        }
    }
    Section("QUALITY") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("720p", vm.quality == 720) { vm.quality = 720 }
            if (AppConfig.quality >= 1080) Chip("1080p", vm.quality == 1080) { vm.quality = 1080 }
        }
        if (AppConfig.watermarkOn && AppConfig.watermarkText.isNotBlank()) Text("A small watermark “" + AppConfig.watermarkText + "” is added to exported videos.", color = Pal.Muted, fontSize = 11.sp)
    }
    when (st) {
        is ExportState.Idle -> GradientButton("📤  Export to gallery  (" + formatTime(vm.totalMs) + ")", modifier = Modifier.fillMaxWidth()) { startExport() }
        is ExportState.Running -> Section("EXPORTING") {
            LinearProgressIndicator(progress = { st.percent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Pal.Pink, trackColor = Pal.Panel2)
            Text("${st.percent}%  Keep this screen open.", color = Pal.Muted, fontSize = 12.sp)
            TextButton(onClick = { vm.cancelExport() }) { Text("Cancel", color = Pal.Pink) }
        }
        is ExportState.Done -> Section("✅ DONE") {
            Text(if (st.uri.authority == "media") "Saved to your gallery (Movies › VideoPro)." else "Saved inside the app only, because storage permission was refused. Export again and allow it to see the video in your gallery.", color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Share", true) {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, st.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    ctx.startActivity(Intent.createChooser(i, null))
                }
                Chip("Play", false) {
                    val i = Intent(Intent.ACTION_VIEW).apply { setDataAndType(st.uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    try { ctx.startActivity(i) } catch (e: Exception) { /* no player app */ }
                }
                Chip("Keep editing", false) { vm.resetExport() }
            }
        }
        is ExportState.Failed -> Section("SOMETHING WENT WRONG") {
            Text(st.message, color = Pal.Pink, fontSize = 13.sp)
            Text("Try 720p, or fewer clips and effects, then export again.", color = Pal.Muted, fontSize = 12.sp)
            Chip("Try again", true) { vm.resetExport() }
        }
    }
}
