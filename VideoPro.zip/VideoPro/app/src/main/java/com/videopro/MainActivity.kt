@file:OptIn(ExperimentalMaterial3Api::class)

package com.videopro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        setContent {
            VideoProTheme {
                val vm: EditorViewModel = viewModel()
                Surface(color = Pal.Bg, modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                    if (vm.clips.isEmpty()) Home(vm) else Editor(vm)
                }
            }
        }
    }
}

// ───────────────────────── small building blocks ─────────────────────────

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .clip(shape)
            .then(if (selected) Modifier.background(Brush.horizontalGradient(listOf(Pal.Violet, Pal.Pink))) else Modifier.background(Pal.Panel2))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (selected) Color.White else Pal.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ToolButton(emoji: String, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Pal.Panel2)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .width(58.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 20.sp, color = if (enabled) Color.White else Pal.Muted)
        Text(label, fontSize = 11.sp, color = if (enabled) Pal.Text else Pal.Muted, maxLines = 1)
    }
}

@Composable
fun GradientButton(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (enabled) Brush.horizontalGradient(listOf(Pal.Violet, Pal.Pink)) else Brush.horizontalGradient(listOf(Pal.Panel2, Pal.Panel2)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Pal.Panel).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Pal.Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        content()
    }
}

// ───────────────────────── home ─────────────────────────

@Composable
fun Home(vm: EditorViewModel) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addClips(it) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3B1D8F), Pal.Bg)))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier.size(112.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pal.Violet, Pal.Pink))),
            contentAlignment = Alignment.Center,
        ) { Text("🎬", fontSize = 52.sp) }
        Spacer(Modifier.height(22.dp))
        Text(stringResource(R.string.app_name), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("Edit videos on your phone.\nNo internet needed. Your videos stay with you.", color = Pal.Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(30.dp))
        GradientButton("＋  New project", onClick = { pick.launch(arrayOf("video/*")) })
        Spacer(Modifier.height(28.dp))
        val feats = listOf("trim" to "✂️ Trim", "speed" to "⚡ Speed", "filters" to "🎨 Filters", "text" to "🔤 Text", "music" to "🎵 Music", "ratio" to "📐 Ratios").filter { AppConfig.has(it.first) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (f in feats.take(3)) Chip(f.second, false) {}
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (f in feats.drop(3)) Chip(f.second, false) {}
        }
    }
}

// ───────────────────────── editor ─────────────────────────

private fun applyPlaybackSettings(player: ExoPlayer, clips: List<Clip>) {
    val c = clips.getOrNull(player.currentMediaItemIndex) ?: return
    player.playbackParameters = PlaybackParameters(c.speed)
    player.volume = if (c.muted) 0f else 1f
}

private fun projectTime(player: ExoPlayer, clips: List<Clip>): Long {
    val idx = player.currentMediaItemIndex
    val cur = clips.getOrNull(idx) ?: return 0L
    val before = clips.take(idx).sumOf { it.effectiveMs }
    return before + (player.currentPosition.coerceAtLeast(0) / cur.speed).toLong()
}

private fun seekProject(player: ExoPlayer, clips: List<Clip>, t: Long) {
    var acc = 0L
    for ((i, c) in clips.withIndex()) {
        val len = c.effectiveMs
        if (t < acc + len || i == clips.lastIndex) {
            val pos = ((t - acc).coerceAtLeast(0) * c.speed).toLong().coerceIn(0L, c.endMs - c.startMs)
            player.seekTo(i, pos)
            applyPlaybackSettings(player, clips)
            return
        }
        acc += len
    }
}

@Composable
fun Editor(vm: EditorViewModel) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var playing by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableStateOf("edit") }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { applyPlaybackSettings(player, vm.clips) }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    // Rebuild the preview when clips are added, removed, reordered or trimmed
    val structure = vm.clips.map { Triple(it.id, it.startMs, it.endMs) }
    LaunchedEffect(structure) {
        val items = vm.clips.map { c ->
            MediaItem.Builder().setUri(c.uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build())
                .build()
        }
        val idx = player.currentMediaItemIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        val pos = if (player.mediaItemCount == items.size) player.currentPosition else 0L
        player.setMediaItems(items, idx, pos)
        player.prepare()
        applyPlaybackSettings(player, vm.clips)
    }
    val settings = vm.clips.map { Triple(it.id, it.speed, it.muted) }
    LaunchedEffect(settings) { applyPlaybackSettings(player, vm.clips) }

    LaunchedEffect(player) {
        while (true) {
            if (!dragging) vm.playhead = projectTime(player, vm.clips)
            delay(100)
        }
    }

    val addClips = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addClips(it) }
    val total = vm.totalMs

    Column(modifier = Modifier.fillMaxSize().background(Pal.Bg)) {
        // top bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("🎬 " + stringResource(R.string.app_name), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { player.pause(); vm.newProject() }) { Text("Close project", color = Pal.Pink) }
        }

        // preview
        Box(modifier = Modifier.fillMaxWidth().height(220.dp).background(Color.Black), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { useController = false; this.player = player } },
                modifier = Modifier.fillMaxSize(),
            )
            for (t in vm.texts) {
                if (AppConfig.has("text") && vm.playhead >= t.startMs && vm.playhead <= t.endMs) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        contentAlignment = when (t.pos) { TextPos.TOP -> Alignment.TopCenter; TextPos.CENTER -> Alignment.Center; TextPos.BOTTOM -> Alignment.BottomCenter },
                    ) { Text(t.text, color = Color(t.color), fontSize = t.size.previewSp.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                }
            }
        }

        // play controls
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = { if (player.isPlaying) player.pause() else { if (vm.playhead >= total - 100) seekProject(player, vm.clips, 0); player.play() } }) {
                Text(if (playing) "⏸" else "▶", fontSize = 24.sp, color = Color.White)
            }
            Text(formatTime(vm.playhead) + " / " + formatTime(total), color = Pal.Muted, fontSize = 12.sp)
            Slider(
                value = vm.playhead.toFloat().coerceIn(0f, total.toFloat().coerceAtLeast(1f)),
                onValueChange = { dragging = true; vm.playhead = it.toLong(); seekProject(player, vm.clips, it.toLong()) },
                onValueChangeFinished = { dragging = false },
                valueRange = 0f..total.toFloat().coerceAtLeast(1f),
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
        }

        // clip strip
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(vm.clips, key = { it.id }) { c ->
                val thumb by produceState<android.graphics.Bitmap?>(null, c.uri, c.startMs) {
                    value = withContext(Dispatchers.IO) { vm.thumbnail(c.uri, c.startMs) }
                }
                val sel = c.id == vm.selectedId
                Box(
                    modifier = Modifier
                        .size(width = 92.dp, height = 62.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Pal.Panel2)
                        .border(BorderStroke(if (sel) 3.dp else 0.dp, if (sel) Pal.Pink else Color.Transparent), RoundedCornerShape(12.dp))
                        .clickable {
                            vm.selectedId = c.id
                            val before = vm.clips.takeWhile { it.id != c.id }.sumOf { it.effectiveMs }
                            seekProject(player, vm.clips, before)
                            vm.playhead = before
                        },
                ) {
                    val b = thumb
                    if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Text(
                        formatTime(c.effectiveMs) + if (c.speed != 1f) " ⚡" else "",
                        color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.BottomEnd).background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
            }
            item {
                Box(
                    modifier = Modifier.size(width = 62.dp, height = 62.dp).clip(RoundedCornerShape(12.dp)).background(Pal.Panel2)
                        .clickable { addClips.launch(arrayOf("video/*")) },
                    contentAlignment = Alignment.Center,
                ) { Text("＋", color = Pal.Pink, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
            }
        }

        // tabs
        val tabs = buildList {
            add("edit" to "✂️ Edit")
            if (AppConfig.has("text")) add("text" to "🔤 Text")
            if (AppConfig.has("music")) add("music" to "🎵 Music")
            add("export" to "📤 Export")
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) { for ((k, label) in tabs) Chip(label, tab == k) { tab = k } }

        // panel
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (tab) {
                "text" -> TextPanel(vm)
                "music" -> MusicPanel(vm)
                "export" -> ExportPanel(vm)
                else -> EditPanel(vm, player)
            }
        }
    }
}

// ───────────────────────── edit panel ─────────────────────────

@Composable
fun EditPanel(vm: EditorViewModel, player: ExoPlayer) {
    val c = vm.selected
    if (c == null) {
        Text("Tap a clip above to edit it.", color = Pal.Muted)
        return
    }
    Section("CLIP") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
            if (AppConfig.has("trim")) ToolButton("✂️", "Split") { vm.split(vm.playhead) }
            ToolButton("◀", "Earlier", vm.clips.indexOfFirst { it.id == c.id } > 0) { vm.move(c.id, -1) }
            ToolButton("▶", "Later", vm.clips.indexOfFirst { it.id == c.id } < vm.clips.size - 1) { vm.move(c.id, 1) }
            if (AppConfig.has("volume")) ToolButton(if (c.muted) "🔇" else "🔊", if (c.muted) "Unmute" else "Mute") { vm.update(c.id) { it.copy(muted = !it.muted) } }
            if (AppConfig.has("rotate")) {
                ToolButton("⟳", "Rotate") { vm.update(c.id) { it.copy(rotate = (it.rotate + 90) % 360) } }
                ToolButton("⇋", "Flip") { vm.update(c.id) { it.copy(flip = !it.flip) } }
            }
            ToolButton("🗑", "Delete") { player.pause(); vm.delete(c.id) }
        }
    }

    if (AppConfig.has("trim")) {
        var range by remember(c.id, c.startMs, c.endMs) { mutableStateOf(c.startMs.toFloat()..c.endMs.toFloat()) }
        Section("TRIM  " + formatTime(range.start.toLong()) + " – " + formatTime(range.endInclusive.toLong())) {
            RangeSlider(
                value = range,
                onValueChange = { r ->
                    var s = r.start
                    var e = r.endInclusive
                    if (e - s < 500f) { if (s != range.start) s = e - 500f else e = s + 500f }
                    range = s.coerceAtLeast(0f)..e.coerceAtMost(c.durationMs.toFloat())
                },
                onValueChangeFinished = { vm.update(c.id) { it.copy(startMs = range.start.toLong(), endMs = range.endInclusive.toLong()) } },
                valueRange = 0f..c.durationMs.toFloat(),
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
            )
        }
    }

    if (AppConfig.has("speed")) {
        Section("SPEED") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (s in listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 3f)) Chip(if (s == 1f) "Normal" else "${s}x", c.speed == s) { vm.update(c.id) { it.copy(speed = s) } }
            }
        }
    }

    if (AppConfig.has("filters")) {
        Section("FILTER") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (f in Filter.values()) Chip(f.label, c.filter == f) { vm.update(c.id) { it.copy(filter = f) } }
            }
            Text("Filters and colours appear in the finished video. The preview above shows the original.", color = Pal.Muted, fontSize = 11.sp)
        }
        Section("COLOUR") {
            LabeledSlider("Brightness", c.brightness, -0.5f, 0.5f) { v -> vm.update(c.id) { it.copy(brightness = v) } }
            LabeledSlider("Contrast", c.contrast, -0.5f, 0.5f) { v -> vm.update(c.id) { it.copy(contrast = v) } }
            LabeledSlider("Saturation", c.saturation, -1f, 1f) { v -> vm.update(c.id) { it.copy(saturation = v) } }
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.width(88.dp))
        Slider(
            value = value, onValueChange = onChange, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Cyan, inactiveTrackColor = Pal.Panel2),
            modifier = Modifier.weight(1f),
        )
    }
}

// ───────────────────────── text panel ─────────────────────────

@Composable
fun TextPanel(vm: EditorViewModel) {
    var dialog by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    GradientButton("＋  Add text at " + formatTime(vm.playhead), modifier = Modifier.fillMaxWidth()) { draft = ""; dialog = true }
    if (vm.texts.isEmpty()) Text("Move the playhead to where the text should start, then add it.", color = Pal.Muted, fontSize = 13.sp)
    for (t in vm.texts) {
        var range by remember(t.id, t.startMs, t.endMs) { mutableStateOf(t.startMs.toFloat()..t.endMs.toFloat()) }
        Section("“" + t.text + "”") {
            Text("Shown from " + formatTime(range.start.toLong()) + " to " + formatTime(range.endInclusive.toLong()), color = Pal.Muted, fontSize = 12.sp)
            val max = vm.totalMs.toFloat().coerceAtLeast(1000f)
            RangeSlider(
                value = range.start.coerceIn(0f, max)..range.endInclusive.coerceIn(0f, max),
                onValueChange = { r -> range = r },
                onValueChangeFinished = { vm.updateText(t.id) { it.copy(startMs = range.start.toLong(), endMs = range.endInclusive.toLong()) } },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(thumbColor = Pal.Pink, activeTrackColor = Pal.Violet, inactiveTrackColor = Pal.Panel2),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                for (col in listOf(0xFFFFFFFF, 0xFFFBBF24, 0xFFF472B6, 0xFF22D3EE, 0xFF000000)) {
                    val argb = col.toInt()
                    Box(
                        modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(argb))
                            .border(BorderStroke(if (t.color == argb) 3.dp else 1.dp, if (t.color == argb) Pal.Pink else Pal.Muted), CircleShape)
                            .clickable { vm.updateText(t.id) { it.copy(color = argb) } },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (s in TextSize.values()) Chip(s.label, t.size == s) { vm.updateText(t.id) { it.copy(size = s) } }
                for (p in TextPos.values()) Chip(p.label, t.pos == p) { vm.updateText(t.id) { it.copy(pos = p) } }
            }
            TextButton(onClick = { vm.removeText(t.id) }) { Text("🗑 Remove this text", color = Pal.Pink) }
        }
    }
    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Text on video") },
            text = { OutlinedTextField(value = draft, onValueChange = { draft = it.take(80) }, placeholder = { Text("Type your text") }) },
            confirmButton = { TextButton(onClick = { vm.addText(draft, vm.playhead); dialog = false }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Cancel") } },
        )
    }
}

// ───────────────────────── music panel ─────────────────────────

@Composable
fun MusicPanel(vm: EditorViewModel) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.setMusic(u) }
    val m = vm.music
    if (m == null) {
        GradientButton("🎵  Choose music from your phone", modifier = Modifier.fillMaxWidth()) { pick.launch(arrayOf("audio/*")) }
        Text("Use only music you have the right to use.", color = Pal.Muted, fontSize = 12.sp)
    } else {
        Section("MUSIC") {
            Text(m.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("Length " + formatTime(m.durationMs) + ". It is cut to the length of your video and plays together with the video's own sound. Mute clips to hear only the music.", color = Pal.Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Change", false) { pick.launch(arrayOf("audio/*")) }
                Chip("Remove", false) { vm.music = null }
            }
            Text("The preview above does not play the music. It is added when you export.", color = Pal.Muted, fontSize = 11.sp)
        }
    }
}

// ───────────────────────── export panel ─────────────────────────

@Composable
fun ExportPanel(vm: EditorViewModel) {
    val ctx = LocalContext.current
    val st = vm.exportState
    if (AppConfig.has("ratio")) {
        Section("SHAPE") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth()) {
                for (r in Ratio.values()) Chip(r.label, vm.ratio == r) { vm.ratio = r }
            }
            Text("9:16 for TikTok, Reels and Shorts. 16:9 for YouTube. 1:1 and 4:5 for Instagram posts.", color = Pal.Muted, fontSize = 11.sp)
        }
    }
    Section("QUALITY") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("720p", vm.quality == 720) { vm.quality = 720 }
            if (AppConfig.quality >= 1080) Chip("1080p", vm.quality == 1080) { vm.quality = 1080 }
        }
        if (AppConfig.watermarkOn && AppConfig.watermarkText.isNotBlank()) Text("A small watermark “" + AppConfig.watermarkText + "” is added to exported videos.", color = Pal.Muted, fontSize = 11.sp)
    }
    when (st) {
        is ExportState.Idle -> GradientButton("📤  Export video  (" + formatTime(vm.totalMs) + ")", modifier = Modifier.fillMaxWidth()) { vm.export() }
        is ExportState.Running -> Section("EXPORTING") {
            LinearProgressIndicator(progress = { st.percent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Pal.Pink, trackColor = Pal.Panel2)
            Text("${st.percent}%  Keep this screen open.", color = Pal.Muted, fontSize = 12.sp)
            TextButton(onClick = { vm.cancelExport() }) { Text("Cancel", color = Pal.Pink) }
        }
        is ExportState.Done -> Section("✅ DONE") {
            Text("Saved in your Movies folder (VideoPro).", color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Share", true) {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, st.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    ctx.startActivity(Intent.createChooser(i, null))
                }
                Chip("Play", false) {
                    val i = Intent(Intent.ACTION_VIEW).apply { setDataAndType(st.uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    try { ctx.startActivity(i) } catch (e: Exception) { /* no player app */ }
                }
                Chip("Keep editing", false) { vm.resetExport() }
            }
        }
        is ExportState.Failed -> Section("SOMETHING WENT WRONG") {
            Text(st.message, color = Pal.Pink, fontSize = 13.sp)
            Text("Try 720p, or fewer clips and effects, then export again.", color = Pal.Muted, fontSize = 12.sp)
            Chip("Try again", true) { vm.resetExport() }
        }
    }
}
