package com.videopro

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything the finished video is made from. */
class ProjectSpec(
    val clips: List<Clip>,
    val texts: List<TextItem>,
    val music: MusicTrack?,
    val ratio: Ratio,
    val quality: Int,
    val watermark: String,
)

/** A text that is only visible between its start and end time. */
private class TimedText(private val item: TextItem, private val px: Int) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000
        val on = ms >= item.startMs && ms <= item.endMs
        val s = SpannableString(if (on) item.text else " ")
        if (on) {
            s.setSpan(ForegroundColorSpan(item.color), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(AbsoluteSizeSpan(px), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, item.pos.anchorY).build()
}

class Exporter(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var poll: Runnable? = null

    /** Size of the finished video, always even numbers. */
    private fun outputSize(spec: ProjectSpec): Pair<Int, Int> {
        val first = spec.clips.first()
        val r = if (spec.ratio == Ratio.ORIGINAL) first.displayW.toFloat() / first.displayH.toFloat() else spec.ratio.value
        var short = spec.quality
        if (spec.ratio == Ratio.ORIGINAL) short = minOf(short, minOf(first.displayW, first.displayH)).coerceAtLeast(144)
        val w: Int
        val h: Int
        if (r >= 1f) { h = short; w = (short * r).toInt() } else { w = short; h = (short / r).toInt() }
        return Pair((w / 2) * 2, (h / 2) * 2)
    }

    private fun clipEffects(c: Clip): Effects {
        val video = ArrayList<Effect>()
        if (c.rotate != 0 || c.flip) {
            video.add(
                ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(c.rotate.toFloat())
                    .setScale(if (c.flip) -1f else 1f, 1f)
                    .build()
            )
        }
        if (c.speed != 1f) video.add(SpeedChangeEffect(c.speed))
        when (c.filter) {
            Filter.NONE -> {}
            Filter.BW -> video.add(HslAdjustment.Builder().adjustSaturation(-100f).build())
            Filter.WARM -> video.add(RgbAdjustment.Builder().setRedScale(1.12f).setBlueScale(0.88f).build())
            Filter.COOL -> video.add(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.12f).build())
            Filter.VIVID -> { video.add(HslAdjustment.Builder().adjustSaturation(30f).build()); video.add(Contrast(0.15f)) }
            Filter.FADE -> { video.add(Contrast(-0.2f)); video.add(Brightness(0.08f)) }
        }
        if (c.brightness != 0f) video.add(Brightness(c.brightness.coerceIn(-1f, 1f)))
        if (c.contrast != 0f) video.add(Contrast(c.contrast.coerceIn(-1f, 1f)))
        if (c.saturation != 0f) video.add(HslAdjustment.Builder().adjustSaturation((c.saturation * 100f).coerceIn(-100f, 100f)).build())
        val audio = ArrayList<AudioProcessor>()
        if (c.speed != 1f && !c.muted) {
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(c.speed)
            sonic.setPitch(1f)
            audio.add(sonic)
        }
        return Effects(audio, video)
    }

    fun start(spec: ProjectSpec, onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        try {
            val (w, h) = outputSize(spec)
            val items = spec.clips.map { c ->
                val mi = MediaItem.Builder()
                    .setUri(c.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(c.startMs)
                            .setEndPositionMs(c.endMs)
                            .build()
                    ).build()
                EditedMediaItem.Builder(mi).setEffects(clipEffects(c)).setRemoveAudio(c.muted).build()
            }
            val videoSeq = EditedMediaItemSequence.Builder(*items.toTypedArray()).build()
            val seqs = ArrayList<EditedMediaItemSequence>()
            seqs.add(videoSeq)
            val totalMs = spec.clips.sumOf { it.effectiveMs }
            val music = spec.music
            if (music != null) {
                val mi = MediaItem.Builder()
                    .setUri(music.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setEndPositionMs(minOf(music.durationMs, totalMs))
                            .build()
                    ).build()
                seqs.add(EditedMediaItemSequence.Builder(EditedMediaItem.Builder(mi).setRemoveVideo(true).build()).build())
            }

            // Effects on the whole video: frame size, texts, watermark
            val overall = ArrayList<Effect>()
            overall.add(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            val shortSide = minOf(w, h)
            val overlays = ArrayList<TextureOverlay>()
            for (t in spec.texts) overlays.add(TimedText(t, (shortSide * t.size.fraction).toInt().coerceAtLeast(12)))
            if (spec.watermark.isNotBlank()) {
                val wm = SpannableString(spec.watermark)
                wm.setSpan(ForegroundColorSpan(0xCCFFFFFF.toInt()), 0, wm.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                wm.setSpan(AbsoluteSizeSpan((shortSide * 0.035f).toInt().coerceAtLeast(10)), 0, wm.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                overlays.add(TextOverlay.createStaticTextOverlay(wm, OverlaySettings.Builder().setBackgroundFrameAnchor(0.45f, -0.92f).build()))
            }
            if (overlays.isNotEmpty()) overall.add(OverlayEffect(ImmutableList.copyOf<TextureOverlay>(overlays)))

            val composition = Composition.Builder(seqs)
                .setEffects(Effects(ArrayList<AudioProcessor>(), overall))
                .build()

            val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        stopPoll()
                        onDone(Result.success(out))
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        stopPoll()
                        out.delete()
                        onDone(Result.failure(exportException))
                    }
                })
                .build()
            transformer = t
            t.start(composition, out.absolutePath)

            val holder = ProgressHolder()
            val r = object : Runnable {
                override fun run() {
                    val cur = transformer ?: return
                    if (cur.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                    main.postDelayed(this, 300)
                }
            }
            poll = r
            main.postDelayed(r, 300)
        } catch (e: Exception) {
            stopPoll()
            onDone(Result.failure(e))
        }
    }

    fun cancel() {
        try { transformer?.cancel() } catch (e: Exception) { /* ignore */ }
        stopPoll()
    }

    private fun stopPoll() {
        poll?.let { main.removeCallbacks(it) }
        poll = null
        transformer = null
    }

    /** Puts the finished video in the phone's Movies folder. Returns an address that can be played or shared. */
    fun saveToMovies(file: File): Uri? {
        val name = "VideoPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoPro")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                uri
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return null
                val dest = File(dir, name)
                file.copyTo(dest, true)
                file.delete()
                FileProvider.getUriForFile(ctx, ctx.packageName + ".files", dest)
            }
        } catch (e: Exception) {
            null
        }
    }
}
