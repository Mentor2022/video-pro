package com.videopro

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** What the project list on the home screen shows. */
data class ProjectInfo(val id: Long, val title: String, val updated: Long, val clipCount: Int, val durationMs: Long)

/** Everything needed to bring a project back. */
class SavedProject(
    val id: Long,
    val clips: List<Clip>,
    val texts: List<TextItem>,
    val music: MusicTrack?,
    val voice: MusicTrack?,
    val ratio: Ratio,
    val quality: Int,
)

/** Projects are kept as small JSON files inside the app. Videos themselves stay where they are. */
object ProjectStore {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "projects").also { it.mkdirs() }

    private inline fun <reified E : Enum<E>> enumOr(name: String?, def: E): E =
        try { if (name == null) def else enumValueOf<E>(name) } catch (e: Exception) { def }

    private fun trackJson(t: MusicTrack?): JSONObject? =
        if (t == null) null else JSONObject().put("uri", t.uri.toString()).put("dur", t.durationMs).put("name", t.name).put("vol", t.volume.toDouble())

    private fun trackFrom(j: JSONObject?): MusicTrack? =
        if (j == null) null else MusicTrack(Uri.parse(j.getString("uri")), j.getLong("dur"), j.optString("name", "Music"), j.optDouble("vol", 1.0).toFloat())

    fun save(ctx: Context, p: SavedProject) {
        try {
            val j = JSONObject()
            j.put("id", p.id)
            j.put("updated", System.currentTimeMillis())
            j.put("ratio", p.ratio.name)
            j.put("quality", p.quality)
            j.put("music", trackJson(p.music))
            j.put("voice", trackJson(p.voice))
            val cs = JSONArray()
            for (c in p.clips) {
                cs.put(
                    JSONObject().put("id", c.id).put("uri", c.uri.toString()).put("dur", c.durationMs)
                        .put("w", c.displayW).put("h", c.displayH).put("start", c.startMs).put("end", c.endMs)
                        .put("speed", c.speed.toDouble()).put("muted", c.muted).put("rotate", c.rotate).put("flip", c.flip)
                        .put("filter", c.filter.name).put("b", c.brightness.toDouble()).put("c", c.contrast.toDouble()).put("s", c.saturation.toDouble())
                        .put("image", c.isImage).put("vol", c.volume.toDouble()).put("crop", c.crop.name).put("fi", c.fadeInMs).put("fo", c.fadeOutMs).put("orig", c.originalUri?.toString())
                )
            }
            j.put("clips", cs)
            val ts = JSONArray()
            for (t in p.texts) {
                ts.put(
                    JSONObject().put("id", t.id).put("text", t.text).put("start", t.startMs).put("end", t.endMs)
                        .put("color", t.color).put("size", t.size.name).put("pos", t.pos.name).put("font", t.font.name).put("bold", t.bold)
                )
            }
            j.put("texts", ts)
            val tmp = File(dir(ctx), "${p.id}.tmp")
            tmp.writeText(j.toString())
            tmp.renameTo(File(dir(ctx), "${p.id}.json"))
        } catch (e: Exception) {
            // saving is a convenience; never crash the editor because of it
        }
    }

    fun load(ctx: Context, id: Long): SavedProject? {
        return try {
            val j = JSONObject(File(dir(ctx), "$id.json").readText())
            val clips = ArrayList<Clip>()
            val cs = j.getJSONArray("clips")
            for (i in 0 until cs.length()) {
                val c = cs.getJSONObject(i)
                clips.add(
                    Clip(
                        id = c.getLong("id"), uri = Uri.parse(c.getString("uri")), durationMs = c.getLong("dur"),
                        displayW = c.getInt("w"), displayH = c.getInt("h"), startMs = c.getLong("start"), endMs = c.getLong("end"),
                        speed = c.getDouble("speed").toFloat(), muted = c.getBoolean("muted"), rotate = c.getInt("rotate"), flip = c.getBoolean("flip"),
                        filter = enumOr(c.optString("filter"), Filter.NONE), brightness = c.getDouble("b").toFloat(),
                        contrast = c.getDouble("c").toFloat(), saturation = c.getDouble("s").toFloat(),
                        isImage = c.optBoolean("image", false), volume = c.optDouble("vol", 1.0).toFloat(), crop = enumOr(c.optString("crop"), CropMode.NONE),
                        fadeInMs = c.optLong("fi", 0), fadeOutMs = c.optLong("fo", 0),
                        originalUri = if (c.has("orig") && !c.isNull("orig")) Uri.parse(c.getString("orig")) else null,
                    )
                )
            }
            val texts = ArrayList<TextItem>()
            val ts = j.getJSONArray("texts")
            for (i in 0 until ts.length()) {
                val t = ts.getJSONObject(i)
                texts.add(
                    TextItem(
                        id = t.getLong("id"), text = t.getString("text"), startMs = t.getLong("start"), endMs = t.getLong("end"),
                        color = t.getInt("color"), size = enumOr(t.optString("size"), TextSize.MEDIUM), pos = enumOr(t.optString("pos"), TextPos.BOTTOM),
                        font = enumOr(t.optString("font"), TextFont.SANS), bold = t.optBoolean("bold", true),
                    )
                )
            }
            SavedProject(
                id, clips, texts, trackFrom(j.optJSONObject("music")), trackFrom(j.optJSONObject("voice")),
                enumOr(j.optString("ratio"), Ratio.ORIGINAL), j.optInt("quality", 1080),
            )
        } catch (e: Exception) {
            null
        }
    }

    fun list(ctx: Context): List<ProjectInfo> {
        val out = ArrayList<ProjectInfo>()
        for (f in dir(ctx).listFiles { x -> x.name.endsWith(".json") } ?: emptyArray()) {
            try {
                val j = JSONObject(f.readText())
                val cs = j.getJSONArray("clips")
                var total = 0L
                for (i in 0 until cs.length()) {
                    val c = cs.getJSONObject(i)
                    total += ((c.getLong("end") - c.getLong("start")) / c.getDouble("speed")).toLong()
                }
                val upd = j.optLong("updated", f.lastModified())
                out.add(ProjectInfo(j.getLong("id"), "Project " + java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(j.getLong("id"))), upd, cs.length(), total))
            } catch (e: Exception) {
                // skip broken files
            }
        }
        return out.sortedByDescending { it.updated }
    }

    fun delete(ctx: Context, id: Long) {
        try {
            val v = JSONObject(File(dir(ctx), "$id.json").readText()).optJSONObject("voice")
            if (v != null) Uri.parse(v.getString("uri")).path?.let { File(it).delete() }
        } catch (e: Exception) { /* nothing to clean */ }
        File(dir(ctx), "$id.json").delete()
    }
}
