package com.videopro

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.nio.ByteOrder

/**
 * Offline speech to text (Vosk). The speech model sits in the app's assets folder (put there by the build)
 * and is copied once to the app's private storage. Nothing is sent to the internet.
 */
object SpeechToText {
    private const val MODEL_DIR = "model-en"

    /** A spoken word. Times are in milliseconds from the start of the clip's trimmed part. */
    data class Word(val text: String, val startMs: Long, val endMs: Long)

    data class Caption(val text: String, val startMs: Long, val endMs: Long)

    /** False when this build was made without the speech model. */
    fun available(ctx: Context): Boolean =
        try { ctx.assets.list(MODEL_DIR)?.isNotEmpty() == true } catch (e: Exception) { false }

    private fun copyAssets(ctx: Context, src: String, dst: File) {
        val names = ctx.assets.list(src)
        if (names != null && names.isNotEmpty()) {
            dst.mkdirs()
            for (n in names) copyAssets(ctx, "$src/$n", File(dst, n))
        } else {
            try {
                ctx.assets.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: java.io.FileNotFoundException) {
                dst.mkdirs() // an empty folder inside the model
            }
        }
    }

    fun loadModel(ctx: Context): Model {
        val root = File(ctx.filesDir, "vosk")
        val dir = File(root, MODEL_DIR)
        val done = File(root, "$MODEL_DIR.done")
        if (!done.exists()) {
            dir.deleteRecursively()
            root.mkdirs()
            copyAssets(ctx, MODEL_DIR, dir)
            done.writeText("ok")
        }
        return Model(dir.absolutePath)
    }

    private fun collect(json: String, originMs: Long, into: MutableList<Word>) {
        try {
            val arr = JSONObject(json).optJSONArray("result") ?: return
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                val text = w.optString("word", "")
                if (text.isBlank()) continue
                into.add(Word(text, originMs + (w.optDouble("start", 0.0) * 1000).toLong(), originMs + (w.optDouble("end", 0.0) * 1000).toLong()))
            }
        } catch (e: Exception) { /* ignore a broken piece */ }
    }

    /** Listens to the sound of a clip (only its trimmed part) and returns the words with their times. */
    fun transcribe(ctx: Context, model: Model, clip: Clip, onProgress: (Int) -> Unit): List<Word> {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        var rec: Recognizer? = null
        try {
            ex.setDataSource(ctx, clip.uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return emptyList()
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return emptyList()
            ex.selectTrack(track)
            val startUs = clip.startMs * 1000L
            val endUs = clip.endMs * 1000L
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()
            val r = Recognizer(model, 16000.0f)
            rec = r
            r.setWords(true)

            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val words = ArrayList<Word>()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var originMs = -1L
            var pos = 0.0 // position inside the next block, for resampling to 16000 Hz

            while (!outputDone) {
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        val t = ex.sampleTime
                        if (n < 0 || t > endUs) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, t, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = dec.outputFormat
                    rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    val out = dec.getOutputBuffer(oi)
                    if (out != null && info.size > 0 && info.presentationTimeUs >= startUs) {
                        if (originMs < 0) originMs = (info.presentationTimeUs - startUs) / 1000
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val s = ShortArray(sb.remaining())
                        sb.get(s)
                        val ch = channels.coerceAtLeast(1)
                        val frames = s.size / ch
                        val ratio = rate / 16000.0
                        val width = Math.ceil(ratio).toInt().coerceAtLeast(1)
                        val outS = ShortArray((frames / ratio).toInt() + 2)
                        var k = 0
                        while (pos.toInt() < frames && k < outS.size) {
                            val idx = pos.toInt()
                            var sum = 0L
                            var cnt = 0
                            var j = idx
                            while (j < minOf(frames, idx + width)) {
                                for (c in 0 until ch) { sum += s[j * ch + c]; cnt++ }
                                j++
                            }
                            outS[k++] = (sum / cnt.coerceAtLeast(1)).toShort()
                            pos += ratio
                        }
                        pos -= frames
                        if (pos < 0) pos = 0.0
                        val bytes = ByteArray(k * 2)
                        for (i in 0 until k) {
                            bytes[2 * i] = (outS[i].toInt() and 0xff).toByte()
                            bytes[2 * i + 1] = (outS[i].toInt() shr 8).toByte()
                        }
                        if (k > 0 && r.acceptWaveForm(bytes, bytes.size)) collect(r.result, maxOf(originMs, 0L), words)
                        onProgress(((info.presentationTimeUs - startUs) * 100 / (endUs - startUs).coerceAtLeast(1)).toInt().coerceIn(0, 99))
                    }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    dec.releaseOutputBuffer(oi, false)
                }
            }
            collect(r.finalResult, maxOf(originMs, 0L), words)
            return words
        } finally {
            try { codec?.stop() } catch (e: Exception) { /* ignore */ }
            try { codec?.release() } catch (e: Exception) { /* ignore */ }
            try { rec?.close() } catch (e: Exception) { /* ignore */ }
            try { ex.release() } catch (e: Exception) { /* ignore */ }
        }
    }

    /** Groups words into short captions: a new one after a pause, 6 words or about 34 letters. */
    fun toCaptions(words: List<Word>): List<Caption> {
        val out = ArrayList<Caption>()
        val cur = ArrayList<Word>()
        fun flush() {
            if (cur.isEmpty()) return
            val t = cur.joinToString(" ") { it.text }
            out.add(Caption(t.replaceFirstChar { it.uppercase() }, cur.first().startMs, cur.last().endMs + 250))
            cur.clear()
        }
        for (w in words) {
            if (cur.isNotEmpty()) {
                val gap = w.startMs - cur.last().endMs
                val len = cur.sumOf { it.text.length + 1 } + w.text.length
                if (gap > 700 || cur.size >= 6 || len > 34) flush()
            }
            cur.add(w)
        }
        flush()
        for (i in 0 until out.size - 1) {
            if (out[i].endMs > out[i + 1].startMs) out[i] = out[i].copy(endMs = out[i + 1].startMs)
        }
        return out
    }
}
