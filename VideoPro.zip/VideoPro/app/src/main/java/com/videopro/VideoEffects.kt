package com.videopro

import android.graphics.Matrix
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/** The kind of effect, used to group the buttons like in CapCut. */
enum class FxGroup(val label: String) { MOTION("Motion"), FLASH("Flash"), COLOR("Colour"), RETRO("Retro") }

/** CapCut-style video effects. One effect per clip, with an intensity slider. */
enum class VFx(val label: String, val emoji: String, val group: FxGroup, val motion: Boolean, val color: Boolean) {
    NONE("None", "🚫", FxGroup.MOTION, false, false),

    ZOOM_IN("Zoom in", "🔍", FxGroup.MOTION, true, false),
    ZOOM_OUT("Zoom out", "🔎", FxGroup.MOTION, true, false),
    PULSE("Pulse", "💓", FxGroup.MOTION, true, false),
    HEARTBEAT("Heartbeat", "❤️", FxGroup.MOTION, true, false),
    SHAKE("Shake", "📳", FxGroup.MOTION, true, false),
    SWING("Swing", "🎢", FxGroup.MOTION, true, false),
    DRIFT("Drift", "🌊", FxGroup.MOTION, true, false),

    FLASH("Flash", "⚡", FxGroup.FLASH, false, true),
    STROBE("Strobe", "💡", FxGroup.FLASH, false, true),
    FLICKER("Flicker", "🕯", FxGroup.FLASH, false, true),
    GLITCH("Glitch", "👾", FxGroup.FLASH, true, true),
    DISCO("Disco", "🪩", FxGroup.FLASH, false, true),

    GLOW("Glow", "🌟", FxGroup.COLOR, false, true),
    INVERT("Invert", "🔄", FxGroup.COLOR, false, true),
    NIGHT("Night vision", "🟢", FxGroup.COLOR, false, true),
    DUO("Duotone", "🟣", FxGroup.COLOR, false, true),

    SEPIA("Sepia", "🟤", FxGroup.RETRO, false, true),
    OLD_FILM("Old film", "📽", FxGroup.RETRO, true, true),
    VHS("VHS", "📼", FxGroup.RETRO, true, true),
}

/** One clip's effect on the project timeline. Times are in project milliseconds. */
class FxSegment(val startMs: Long, val endMs: Long, val fx: VFx, val level: Float)

/** How a motion effect moves the picture: scale and shift, in the range -1..1 of the frame. */
class Move(val scale: Float, val dx: Float, val dy: Float)

private val STILL = Move(1f, 0f, 0f)

/** A repeatable pseudo-random number from 0 to 1 for a given step, so the shake looks the same every time. */
private fun hash01(n: Int): Float {
    var x = n * 374761393 + 668265263
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return (x and 0xFFFF) / 65535f
}

private fun noise(t: Float, rate: Float, seed: Int): Float {
    val a = floor(t * rate).toInt()
    val f = t * rate - a
    val v0 = hash01(a * 31 + seed) * 2f - 1f
    val v1 = hash01((a + 1) * 31 + seed) * 2f - 1f
    return v0 + (v1 - v0) * f
}

/** t = seconds since the clip began, p = how far through the clip (0..1). */
fun fxMove(fx: VFx, level: Float, t: Float, p: Float): Move {
    val l = level.coerceIn(0f, 1f)
    return when (fx) {
        VFx.ZOOM_IN -> Move(1f + 0.5f * l * p, 0f, 0f)
        VFx.ZOOM_OUT -> Move(1f + 0.5f * l * (1f - p), 0f, 0f)
        VFx.PULSE -> {
            val beat = max(0f, cos(2f * PI.toFloat() * 2f * t)).pow(4)
            Move(1f + 0.14f * l * beat, 0f, 0f)
        }
        VFx.HEARTBEAT -> {
            val ph = (t * 1.2f) % 1f
            val a = exp(-((ph - 0.10f) * (ph - 0.10f)) / 0.0008f)
            val b = exp(-((ph - 0.28f) * (ph - 0.28f)) / 0.0012f)
            Move(1f + 0.16f * l * (a + 0.7f * b), 0f, 0f)
        }
        VFx.SHAKE -> {
            val s = 1f + 0.10f * l
            val m = 0.05f * l
            Move(s, noise(t, 24f, 1) * m, noise(t, 24f, 2) * m)
        }
        VFx.SWING -> {
            val s = 1f + 0.18f * l
            Move(s, sin(t * 2.2f) * 0.16f * l, sin(t * 1.3f) * 0.05f * l)
        }
        VFx.DRIFT -> {
            val s = 1f + 0.22f * l
            Move(s, (p - 0.5f) * 0.36f * l, 0f)
        }
        VFx.GLITCH -> {
            // short bursts of sideways jumps
            val slot = floor(t * 9f).toInt()
            if (hash01(slot) < 0.28f + 0.25f * l) {
                val s = 1f + 0.06f * l
                Move(s, (hash01(slot + 7) * 2f - 1f) * 0.07f * l, (hash01(slot + 13) * 2f - 1f) * 0.02f * l)
            } else STILL
        }
        VFx.OLD_FILM -> {
            val s = 1f + 0.03f * l
            Move(s, noise(t, 18f, 3) * 0.012f * l, noise(t, 18f, 4) * 0.012f * l)
        }
        VFx.VHS -> {
            val slot = floor(t * 6f).toInt()
            if (hash01(slot + 50) < 0.2f) Move(1.02f, (hash01(slot + 3) * 2f - 1f) * 0.03f * l, 0f) else STILL
        }
        else -> STILL
    }
}

/** A colour change written as rows (what red, green and blue become) plus a shift for each. */
private fun colorMatrix(
    rr: Float, rg: Float, rb: Float, ro: Float,
    gr: Float, gg: Float, gb: Float, go: Float,
    br: Float, bg: Float, bb: Float, bo: Float,
): FloatArray = floatArrayOf(
    // Media3 reads the matrix column by column; the 4th column (multiplied by alpha = 1) is the shift
    rr, gr, br, 0f,
    rg, gg, bg, 0f,
    rb, gb, bb, 0f,
    ro, go, bo, 1f,
)

private val IDENTITY = colorMatrix(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f)

/** Mixes the plain picture (amount 0) with the changed one (amount 1). */
private fun mix(m: FloatArray, amount: Float): FloatArray {
    val a = amount.coerceIn(0f, 1f)
    return FloatArray(16) { i -> IDENTITY[i] + (m[i] - IDENTITY[i]) * a }
}

private fun gain(k: Float, shift: Float = 0f) = colorMatrix(k, 0f, 0f, shift, 0f, k, 0f, shift, 0f, 0f, k, shift)

private fun channels(r: Float, g: Float, b: Float, shift: Float = 0f) = colorMatrix(r, 0f, 0f, shift, 0f, g, 0f, shift, 0f, 0f, b, shift)

private val SEPIA = colorMatrix(
    0.393f, 0.769f, 0.189f, 0f,
    0.349f, 0.686f, 0.168f, 0f,
    0.272f, 0.534f, 0.131f, 0f,
)

private val NIGHT = colorMatrix(
    0.10f, 0.20f, 0.05f, 0.00f,
    0.45f, 0.90f, 0.20f, 0.04f,
    0.05f, 0.10f, 0.03f, 0.00f,
)

private val DUOTONE = colorMatrix(
    // dark = deep purple, light = warm pink
    0.20f, 0.40f, 0.08f, 0.10f,
    0.05f, 0.10f, 0.02f, 0.02f,
    0.25f, 0.50f, 0.10f, 0.20f,
)

/** The colour change for an effect at a moment. t = seconds into the clip. */
fun fxColor(fx: VFx, level: Float, t: Float): FloatArray {
    val l = level.coerceIn(0f, 1f)
    return when (fx) {
        VFx.FLASH -> {
            val ph = t % 1.4f
            gain(1f, 0.7f * l * exp(-ph * 7f))
        }
        VFx.STROBE -> if (floor(t * 8f).toInt() % 2 == 0) gain(1f, 0.28f * l) else gain(1f - 0.15f * l)
        VFx.FLICKER -> gain(1f - 0.35f * l * abs(noise(t, 22f, 5)))
        VFx.DISCO -> channels(
            1f + 0.55f * l * sin(t * 5.0f),
            1f + 0.55f * l * sin(t * 5.0f + 2.1f),
            1f + 0.55f * l * sin(t * 5.0f + 4.2f),
        )
        VFx.GLITCH -> {
            val slot = floor(t * 9f).toInt()
            if (hash01(slot) < 0.28f + 0.25f * l) {
                // a burst: swap red and blue and push the green
                mix(colorMatrix(0f, 0f, 1f, 0f, 0f, 1.1f, 0f, 0f, 1f, 0f, 0f, 0f), 0.5f + 0.5f * l)
            } else IDENTITY
        }
        VFx.GLOW -> {
            // softer contrast, lifted light and a little more colour
            val m = colorMatrix(
                0.95f, 0f, 0f, 0.10f,
                0f, 0.95f, 0f, 0.10f,
                0f, 0f, 0.95f, 0.10f,
            )
            mix(m, l)
        }
        VFx.INVERT -> mix(colorMatrix(-1f, 0f, 0f, 1f, 0f, -1f, 0f, 1f, 0f, 0f, -1f, 1f), l)
        VFx.NIGHT -> mix(NIGHT, 0.4f + 0.6f * l)
        VFx.DUO -> mix(DUOTONE, 0.3f + 0.7f * l)
        VFx.SEPIA -> mix(SEPIA, l)
        VFx.OLD_FILM -> {
            val flick = 1f - 0.18f * l * abs(noise(t, 16f, 9))
            val base = mix(SEPIA, 0.55f * (0.4f + 0.6f * l))
            FloatArray(16) { i -> if (i % 5 == 0 && i < 15) base[i] * flick else base[i] }
        }
        VFx.VHS -> {
            val slot = floor(t * 6f).toInt()
            val hit = hash01(slot + 50) < 0.2f
            // slightly washed colours, red shifted warm, and a brighter wobble when the tape "slips"
            val base = channels(1.06f, 0.96f, 1.04f, if (hit) 0.08f * l else 0.02f * l)
            mix(base, 0.4f + 0.6f * l)
        }
        else -> IDENTITY
    }
}

/** The motion effects for the whole video. Outside a clip's effect nothing moves. */
class FxMotion(private val segs: List<FxSegment>) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val ms = presentationTimeUs / 1000f
        val m = Matrix()
        for (s in segs) {
            if (!s.fx.motion || ms < s.startMs || ms > s.endMs) continue
            val len = (s.endMs - s.startMs).coerceAtLeast(1L).toFloat()
            val mv = fxMove(s.fx, s.level, (ms - s.startMs) / 1000f, ((ms - s.startMs) / len).coerceIn(0f, 1f))
            m.setScale(mv.scale, mv.scale)
            m.postTranslate(mv.dx, mv.dy)
            break
        }
        return m
    }
}

/** The colour effects for the whole video. */
class FxColor(private val segs: List<FxSegment>) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        val ms = presentationTimeUs / 1000f
        for (s in segs) {
            if (!s.fx.color || ms < s.startMs || ms > s.endMs) continue
            return fxColor(s.fx, s.level, (ms - s.startMs) / 1000f)
        }
        return IDENTITY
    }
}
