package com.videopro

import android.net.Uri

enum class Filter(val label: String) {
    NONE("Original"), BW("B&W"), WARM("Warm"), COOL("Cool"), VIVID("Vivid"), FADE("Fade")
}

enum class Ratio(val label: String, val value: Float) {
    ORIGINAL("Original", 0f), WIDE("16:9", 16f / 9f), TALL("9:16", 9f / 16f), SQUARE("1:1", 1f), PORTRAIT("4:5", 0.8f)
}

enum class TextPos(val label: String, val anchorY: Float) {
    TOP("Top", 0.75f), CENTER("Middle", 0f), BOTTOM("Bottom", -0.75f)
}

enum class TextSize(val label: String, val fraction: Float, val previewSp: Int) {
    SMALL("Small", 0.05f, 14), MEDIUM("Medium", 0.08f, 22), LARGE("Large", 0.12f, 32)
}

/** One piece of video on the timeline. Times are in the original video, in milliseconds. */
data class Clip(
    val id: Long,
    val uri: Uri,
    val durationMs: Long,
    val displayW: Int,
    val displayH: Int,
    val startMs: Long = 0,
    val endMs: Long = durationMs,
    val speed: Float = 1f,
    val muted: Boolean = false,
    val rotate: Int = 0,
    val flip: Boolean = false,
    val filter: Filter = Filter.NONE,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
) {
    /** How long this piece lasts in the finished video. */
    val effectiveMs: Long get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1)
}

/** A text on the finished video. Times are on the project timeline. */
data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val color: Int = 0xFFFFFFFF.toInt(),
    val size: TextSize = TextSize.MEDIUM,
    val pos: TextPos = TextPos.BOTTOM,
)

data class MusicTrack(val uri: Uri, val durationMs: Long, val name: String)

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val percent: Int) : ExportState()
    data class Done(val uri: Uri) : ExportState()
    data class Failed(val message: String) : ExportState()
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
