package com.videopro

import android.net.Uri

enum class Filter(val label: String) {
    NONE("Original"), BW("B&W"), WARM("Warm"), COOL("Cool"), VIVID("Vivid"), FADE("Fade")
}

enum class Ratio(val label: String, val value: Float) {
    ORIGINAL("Original", 0f), WIDE("16:9", 16f / 9f), TALL("9:16", 9f / 16f), SQUARE("1:1", 1f), PORTRAIT("4:5", 0.8f)
}

/** Cuts the picture to a shape. The centre is kept. */
enum class CropMode(val label: String, val ratio: Float) {
    NONE("None", 0f), SQUARE("1:1", 1f), WIDE("16:9", 16f / 9f), TALL("9:16", 9f / 16f), PORTRAIT("4:5", 0.8f)
}

/** Fonts that every Android phone already has, so nothing extra is added to the app. */
enum class TextFont(val label: String, val family: String) {
    SANS("Sans", "sans-serif"), SERIF("Serif", "serif"), MONO("Mono", "monospace"), NARROW("Narrow", "sans-serif-condensed"), SCRIPT("Script", "cursive")
}

/** Ready-made caption looks, like CapCut. A colour of null keeps the colour chosen for the text. */
enum class CapStyle(val label: String, val color: Int?, val bg: Int, val shadow: Int, val glow: Boolean = false) {
    PLAIN("Plain", null, 0, 0),
    BOX("Dark box", 0xFFFFFFFF.toInt(), 0xB3000000.toInt(), 0),
    SHADOW("Shadow", null, 0, 0xFF000000.toInt()),
    YELLOW("Yellow", 0xFFFBBF24.toInt(), 0, 0xFF000000.toInt()),
    HIGHLIGHT("Highlight", 0xFF000000.toInt(), 0xFFFBBF24.toInt(), 0),
    PINK("Pink box", 0xFFFFFFFF.toInt(), 0xFFF472B6.toInt(), 0),
    NEON("Neon", 0xFF22D3EE.toInt(), 0, 0xFF22D3EE.toInt(), true),
}

enum class TextAnim(val label: String) {
    NONE("No motion"), POP("Pop"), SLIDE("Slide up"), FADE("Fade"), BOUNCE("Bounce")
}

enum class TextPos(val label: String, val anchorY: Float) {
    TOP("Top", 0.75f), CENTER("Middle", 0f), BOTTOM("Bottom", -0.75f)
}

enum class TextSize(val label: String, val fraction: Float, val previewSp: Int) {
    SMALL("Small", 0.05f, 14), MEDIUM("Medium", 0.08f, 22), LARGE("Large", 0.12f, 32)
}

/** One piece of video on the timeline. Times are in the original video, in milliseconds. */
data class Clip(
    val id: Long,
    val uri: Uri,
    val durationMs: Long,
    val displayW: Int,
    val displayH: Int,
    val startMs: Long = 0,
    val endMs: Long = durationMs,
    val speed: Float = 1f,
    val muted: Boolean = false,
    val rotate: Int = 0,
    val flip: Boolean = false,
    val filter: Filter = Filter.NONE,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    /** A photo instead of a video. Its length is endMs - startMs. */
    val isImage: Boolean = false,
    /** 1 = original loudness, 0 = silent, 2 = twice as loud. */
    val volume: Float = 1f,
    val crop: CropMode = CropMode.NONE,
    /** Fade from / to black at the start / end of this clip, in milliseconds (0 = none). */
    val fadeInMs: Long = 0,
    val fadeOutMs: Long = 0,
    /** For photos whose background was removed: the photo before that, so it can be restored. */
    val originalUri: Uri? = null,
    /** CapCut-style effect on this clip, and how strong it is (0..1). */
    val effect: VFx = VFx.NONE,
    val effectLevel: Float = 0.6f,
    /** Transition between this clip and the next one. */
    val transition: Trans = Trans.NONE,
) {
    /** How long this piece lasts in the finished video. */
    val effectiveMs: Long get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1)
}

/** A text on the finished video. Times are on the project timeline. */
data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val color: Int = 0xFFFFFFFF.toInt(),
    val size: TextSize = TextSize.MEDIUM,
    val pos: TextPos = TextPos.BOTTOM,
    val font: TextFont = TextFont.SANS,
    val bold: Boolean = true,
    /** Typewriter: the letters appear one by one at the start of the text. */
    val animate: Boolean = false,
    /** How the text comes in: pop, slide, fade or bounce. */
    val motion: TextAnim = TextAnim.NONE,
    val style: CapStyle = CapStyle.PLAIN,
)

/** How many letters of an animated text are visible at this time. The typing takes about 90 ms per letter, at most 70% of the text's time. */
fun revealCount(item: TextItem, ms: Long): Int {
    val n = item.text.length
    if (!item.animate) return n
    val reveal = minOf(((item.endMs - item.startMs) * 0.7).toLong(), n * 90L).coerceAtLeast(1L)
    val f = ((ms - item.startMs).toFloat() / reveal).coerceIn(0f, 1f)
    return kotlin.math.ceil(n * f.toDouble()).toInt().coerceIn(0, n)
}

data class MusicTrack(val uri: Uri, val durationMs: Long, val name: String, val volume: Float = 1f)

/** A ready-made look. It sets colours, shape and fades in one tap. */
class Look(val name: String, val emoji: String, val filter: Filter, val brightness: Float, val contrast: Float, val saturation: Float, val ratio: Ratio?, val fade: Boolean, val title: String?)

val LOOKS = listOf(
    Look("Cinematic", "🎞", Filter.COOL, -0.03f, 0.2f, -0.1f, Ratio.WIDE, true, null),
    Look("Vlog", "📱", Filter.VIVID, 0.05f, 0.05f, 0.15f, Ratio.TALL, false, null),
    Look("Retro", "📼", Filter.WARM, 0.02f, 0.1f, -0.25f, null, true, null),
    Look("Film B&W", "🖤", Filter.BW, 0f, 0.25f, 0f, Ratio.WIDE, true, null),
    Look("Dreamy", "🌸", Filter.FADE, 0.08f, -0.05f, 0.2f, null, true, null),
    Look("Clean", "⚪", Filter.NONE, 0f, 0f, 0f, null, false, null),
)

/** Where a picture-in-picture sits. ax / ay are -1 (left / bottom), 0 (middle) or 1 (right / top). */
enum class PipPos(val label: String, val ax: Float, val ay: Float) {
    TL("Top left", -1f, 1f), TR("Top right", 1f, 1f), BL("Bottom left", -1f, -1f), BR("Bottom right", 1f, -1f), CENTER("Middle", 0f, 0f)
}

enum class PipSize(val label: String, val fraction: Float) { SMALL("Small", 0.28f), MEDIUM("Medium", 0.4f), LARGE("Large", 0.6f) }

/** A small video or photo shown on top of the main video. Times are on the project timeline. It plays from its start and has no sound. */
data class PipItem(
    val id: Long,
    val uri: Uri,
    val isImage: Boolean,
    val durationMs: Long,
    val displayW: Int,
    val displayH: Int,
    val startMs: Long,
    val lengthMs: Long,
    val pos: PipPos = PipPos.BR,
    val size: PipSize = PipSize.MEDIUM,
)

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val percent: Int) : ExportState()
    data class Done(val uri: Uri) : ExportState()
    data class Failed(val message: String) : ExportState()
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
