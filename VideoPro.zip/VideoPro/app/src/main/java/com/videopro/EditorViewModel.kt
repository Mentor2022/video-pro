package com.videopro

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.graphics.Matrix
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteBuffer
import org.vosk.Model
import java.nio.ByteOrder
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    var clips by mutableStateOf<List<Clip>>(emptyList())
    var selectedId by mutableStateOf<Long?>(null)
    var texts by mutableStateOf<List<TextItem>>(emptyList())
    var music by mutableStateOf<MusicTrack?>(null)
    var voice by mutableStateOf<MusicTrack?>(null)
    var recording by mutableStateOf(false)
    var projects by mutableStateOf<List<ProjectInfo>>(emptyList())
    private var projectId: Long? = null
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var recStart = 0L
    var ratio by mutableStateOf(Ratio.ORIGINAL)
    var quality by mutableStateOf(minOf(AppConfig.quality, 1080))
    var playhead by mutableStateOf(0L)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)

    private var nextId = 1L

    /** True while a photo is being worked on (background removal). */
    var busy by mutableStateOf(false)

    // ───── auto-captions (speech to text) ─────

    /** Shows what the speech-to-text is doing. Null when it is not running. */
    var captionStatus by mutableStateOf<String?>(null)

    /** Listens to the video and adds timed captions. onlyId = one clip, null = every clip with sound. */
    fun autoCaption(onlyId: Long?) {
        if (captionStatus != null) return
        val ctx = getApplication<Application>()
        val targets = clips.filter { !it.isImage && !it.muted && (onlyId == null || it.id == onlyId) }
        if (targets.isEmpty()) { toast("There is no clip with sound to listen to."); return }
        if (!SpeechToText.available(ctx)) { toast("This version of the app was built without the speech model."); return }
        captionStatus = "Loading the speech model…"
        val snapshot = clips
        viewModelScope.launch(Dispatchers.Default) {
            var model: Model? = null
            try {
                val m = SpeechToText.loadModel(ctx)
                model = m
                val made = ArrayList<TextItem>()
                for ((n, c) in targets.withIndex()) {
                    val offset = snapshot.takeWhile { it.id != c.id }.sumOf { it.effectiveMs }
                    val words = SpeechToText.transcribe(ctx, m, c) { p -> captionStatus = "Listening to clip " + (n + 1) + " of " + targets.size + "…  " + p + "%" }
                    for (cap in SpeechToText.toCaptions(words)) {
                        val start = offset + (cap.startMs / c.speed).toLong()
                        val end = minOf(offset + c.effectiveMs, offset + (cap.endMs / c.speed).toLong()).coerceAtLeast(start + 300)
                        made.add(TextItem(id = nextId++, text = cap.text.take(80), startMs = start, endMs = end))
                    }
                }
                withContext(Dispatchers.Main) {
                    if (made.isEmpty()) toast("No speech was found. Try a clip with clear talking.")
                    else { checkpoint(); texts = texts + made; toast("Added " + made.size + " captions. Check the words and fix any mistakes.") }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { toast("Auto-captions failed: " + (e.message ?: e.javaClass.simpleName)) }
            } finally {
                try { model?.close() } catch (e: Throwable) { /* ignore */ }
                captionStatus = null
            }
        }
    }

    // ───── looks (templates) ─────

    fun applyLook(look: Look) {
        if (clips.isEmpty()) return
        checkpoint()
        val last = clips.lastIndex
        clips = clips.mapIndexed { i, c ->
            c.copy(
                filter = look.filter, brightness = look.brightness, contrast = look.contrast, saturation = look.saturation,
                fadeInMs = if (look.fade && i == 0) 800 else 0, fadeOutMs = if (look.fade && i == last) 800 else 0,
            )
        }
        if (look.ratio != null) ratio = look.ratio
    }

    /** Gives every clip the same effect. */
    fun applyEffectToAll(fx: VFx, level: Float) {
        if (clips.isEmpty()) return
        checkpoint()
        clips = clips.map { it.copy(effect = fx, effectLevel = level) }
    }

    // ───── background removal (photos) ─────

    /** Opens a photo the right way up and not larger than maxSide. */
    private fun loadUpright(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return null
            val orientation = try {
                ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
            } catch (e: Exception) { null } ?: ExifInterface.ORIENTATION_NORMAL
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            }
            if (m.isIdentity) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Exception) {
            null
        }
    }

    /** The mask is a list of numbers from 0 to 1 (how sure the model is that a pixel is a person). */
    private fun maskFloats(buf: ByteBuffer, count: Int): FloatArray {
        val base = buf.duplicate()
        fun looksRight(o: ByteOrder): Boolean {
            val t = base.duplicate().order(o)
            t.rewind()
            var i = 0
            while (i < minOf(count, 400) && t.remaining() >= 4) {
                val f = t.getFloat()
                if (f.isNaN() || f < -0.01f || f > 1.01f) return false
                i++
            }
            return true
        }
        val order = if (looksRight(ByteOrder.nativeOrder())) ByteOrder.nativeOrder() else ByteOrder.BIG_ENDIAN
        val t = base.duplicate().order(order)
        t.rewind()
        val out = FloatArray(count)
        for (i in 0 until count) out[i] = if (t.remaining() >= 4) t.getFloat() else 0f
        return out
    }

    private fun composeCutout(src: Bitmap, mask: SegmentationMask, bg: Int): Bitmap {
        val w = src.width
        val h = src.height
        val mw = mask.width
        val mh = mask.height
        val conf = maskFloats(mask.buffer, mw * mh)
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val br = android.graphics.Color.red(bg)
        val bgG = android.graphics.Color.green(bg)
        val bb = android.graphics.Color.blue(bg)
        for (y in 0 until h) {
            val my = (y * mh / h).coerceAtMost(mh - 1)
            for (x in 0 until w) {
                val mx = (x * mw / w).coerceAtMost(mw - 1)
                // soft edge: below 0.3 is background, above 0.7 is person
                val a = ((conf[my * mw + mx] - 0.3f) / 0.4f).coerceIn(0f, 1f)
                val p = px[y * w + x]
                val r = (android.graphics.Color.red(p) * a + br * (1f - a)).toInt()
                val g = (android.graphics.Color.green(p) * a + bgG * (1f - a)).toInt()
                val b = (android.graphics.Color.blue(p) * a + bb * (1f - a)).toInt()
                px[y * w + x] = android.graphics.Color.rgb(r, g, b)
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun saveCutout(ctx: Context, bmp: Bitmap): File? {
        return try {
            val dir = File(ctx.filesDir, "cutouts").also { it.mkdirs() }
            val f = File(dir, "cut_" + System.currentTimeMillis() + ".jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            f
        } catch (e: Exception) {
            null
        }
    }

    /** Replaces everything behind the person in a photo with a plain colour. Works offline. */
    fun removeBackground(id: Long, bgColor: Int) {
        val c = clips.firstOrNull { it.id == id } ?: return
        if (!c.isImage || busy) return
        busy = true
        val ctx = getApplication<Application>()
        val source = c.originalUri ?: c.uri
        viewModelScope.launch {
            val src = withContext(Dispatchers.IO) { loadUpright(ctx, source, 1280) }
            if (src == null) { busy = false; toast("This photo could not be opened."); return@launch }
            val segmenter = Segmentation.getClient(SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build())
            segmenter.process(InputImage.fromBitmap(src, 0))
                .addOnSuccessListener { mask ->
                    viewModelScope.launch {
                        val out = withContext(Dispatchers.Default) { composeCutout(src, mask, bgColor) }
                        val saved = withContext(Dispatchers.IO) { saveCutout(ctx, out) }
                        if (saved == null) {
                            toast("The result could not be saved.")
                        } else {
                            checkpoint()
                            clips = clips.map { x ->
                                if (x.id == id) x.copy(uri = Uri.fromFile(saved), displayW = out.width, displayH = out.height, originalUri = x.originalUri ?: x.uri) else x
                            }
                        }
                        busy = false
                        segmenter.close()
                    }
                }
                .addOnFailureListener {
                    busy = false
                    toast("Background removal did not work on this photo. It finds people best.")
                    segmenter.close()
                }
        }
    }

    fun restoreOriginal(id: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        val orig = c.originalUri ?: return
        viewModelScope.launch {
            val back = withContext(Dispatchers.IO) { readImage(getApplication<Application>(), orig) }
            if (back == null) { toast("The original photo can no longer be opened."); return@launch }
            checkpoint()
            clips = clips.map { x -> if (x.id == id) x.copy(uri = orig, displayW = back.displayW, displayH = back.displayH, originalUri = null) else x }
        }
    }

    // ───── undo and redo ─────
    private class Snap(val clips: List<Clip>, val texts: List<TextItem>, val selectedId: Long?)
    private val undoStack = ArrayDeque<Snap>()
    private val redoStack = ArrayDeque<Snap>()
    private var lastEdit = 0L
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    private fun flags() { canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty() }

    /** Remembers the project as it is now, before a change. */
    private fun checkpoint() {
        undoStack.addLast(Snap(clips, texts, selectedId))
        while (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
        lastEdit = SystemClock.elapsedRealtime()
        flags()
    }

    /** Slider drags make many small changes. They count as one step. */
    private fun burstCheckpoint() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastEdit > 700) checkpoint()
        lastEdit = now
    }

    private fun clearHistory() { undoStack.clear(); redoStack.clear(); flags() }

    private fun applySnap(s: Snap) {
        clips = s.clips
        texts = s.texts
        selectedId = if (s.selectedId != null && s.clips.any { it.id == s.selectedId }) s.selectedId else s.clips.firstOrNull()?.id
    }

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(Snap(clips, texts, selectedId))
        applySnap(s)
        flags()
    }

    fun redo() {
        val s = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(Snap(clips, texts, selectedId))
        applySnap(s)
        flags()
    }
    private val exporter = Exporter(app)

    val totalMs: Long get() = clips.sumOf { it.effectiveMs }
    val selected: Clip? get() = clips.firstOrNull { it.id == selectedId }

    private fun toast(msg: String) {
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_LONG).show()
    }

    /** Reads the size of a photo. A photo starts with a length of 4 seconds. */
    private fun readImage(ctx: Context, uri: Uri): Clip? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var w = o.outWidth
            var h = o.outHeight
            if (w <= 0 || h <= 0) return null
            val orientation = try {
                ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
            } catch (e: Exception) { null } ?: ExifInterface.ORIENTATION_NORMAL
            if (orientation in 5..8) { val t = w; w = h; h = t }
            Clip(id = nextId++, uri = uri, durationMs = 15000, displayW = w, displayH = h, startMs = 0, endMs = 4000, isImage = true)
        } catch (e: Exception) {
            null
        }
    }

    private fun isImageUri(ctx: Context, uri: Uri): Boolean =
        try { ctx.contentResolver.getType(uri)?.startsWith("image/") == true } catch (e: Exception) { false }

    /** Reads length and size of a video or photo. Returns null when the file cannot be used. */
    private fun readClip(ctx: Context, uri: Uri): Clip? {
        if (isImageUri(ctx, uri)) return readImage(ctx, uri)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur < 500 || w <= 0 || h <= 0) null else Clip(id = nextId++, uri = uri, durationMs = dur, displayW = w, displayH = h)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { /* ignore */ }
        }
    }

    private fun keepAccess(uri: Uri) {
        try { getApplication<Application>().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { /* not offered by this picker */ }
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        for (u in uris) keepAccess(u)
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { readClip(ctx, it) } }
            if (loaded.size < uris.size) toast("Some files could not be opened as videos or photos.")
            if (loaded.isNotEmpty()) {
                checkpoint()
                clips = clips + loaded
                if (selectedId == null) selectedId = loaded.first().id
            }
        }
    }

    fun update(id: Long, change: (Clip) -> Clip) {
        burstCheckpoint()
        clips = clips.map { if (it.id == id) change(it) else it }
    }

    fun delete(id: Long) {
        val i = clips.indexOfFirst { it.id == id }
        checkpoint()
        clips = clips.filter { it.id != id }
        selectedId = clips.getOrNull(minOf(i, clips.size - 1).coerceAtLeast(0))?.id
        if (clips.isEmpty()) clearHistory()
    }

    fun duplicate(id: Long) {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        checkpoint()
        val copy = clips[i].copy(id = nextId++)
        val l = clips.toMutableList()
        l.add(i + 1, copy)
        clips = l
        selectedId = copy.id
    }

    fun move(id: Long, delta: Int) {
        val i = clips.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= clips.size) return
        checkpoint()
        val l = clips.toMutableList()
        val c = l.removeAt(i)
        l.add(j, c)
        clips = l
    }

    /** Cuts the clip under the playhead in two. */
    fun split(projectMs: Long) {
        var acc = 0L
        for (c in clips) {
            val len = c.effectiveMs
            if (projectMs < acc + len) {
                val at = c.startMs + ((projectMs - acc) * c.speed).toLong()
                if (at - c.startMs < 300 || c.endMs - at < 300) { toast("Move the playhead to the middle of a clip to split it."); return }
                checkpoint()
                val a = c.copy(endMs = at)
                val b = c.copy(id = nextId++, startMs = at)
                clips = clips.flatMap { if (it.id == c.id) listOf(a, b) else listOf(it) }
                selectedId = b.id
                return
            }
            acc += len
        }
    }

    fun addText(text: String, atMs: Long, animate: Boolean = false) {
        if (text.isBlank()) return
        val total = totalMs
        val end = minOf(total, atMs + 3000)
        checkpoint()
        texts = texts + TextItem(id = nextId++, text = text.trim().take(80), startMs = atMs.coerceAtMost((total - 500).coerceAtLeast(0)), endMs = end.coerceAtLeast(500), animate = animate)
    }

    fun addSticker(emoji: String, atMs: Long) {
        val total = totalMs
        val start = atMs.coerceAtMost((total - 500).coerceAtLeast(0))
        checkpoint()
        texts = texts + TextItem(id = nextId++, text = emoji, startMs = start, endMs = minOf(total, start + 3000).coerceAtLeast(start + 500), size = TextSize.LARGE, pos = TextPos.CENTER)
    }

    fun updateText(id: Long, change: (TextItem) -> TextItem) { burstCheckpoint(); texts = texts.map { if (it.id == id) change(it) else it } }
    fun removeText(id: Long) { checkpoint(); texts = texts.filter { it.id != id } }

    fun setMusic(uri: Uri) {
        keepAccess(uri)
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val track = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    var name = "Music"
                    try {
                        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) name = c.getString(0) ?: name
                        }
                    } catch (e: Exception) { /* keep the default name */ }
                    if (dur > 500) MusicTrack(uri, dur, name) else null
                } catch (e: Exception) {
                    null
                } finally {
                    try { r.release() } catch (e: Exception) { /* ignore */ }
                }
            }
            if (track == null) toast("That file could not be used as music.") else music = track
        }
    }

    fun thumbnail(c: Clip): Bitmap? {
        val uri = c.uri
        val atMs = c.startMs
        if (c.isImage) {
            return try {
                val ctx = getApplication<Application>()
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= 220) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            val b = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val s = 220f / maxOf(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { /* ignore */ }
        }
    }

    fun export() {
        if (clips.isEmpty() || exportState is ExportState.Running) return
        exportState = ExportState.Running(0)
        val wm = if (AppConfig.watermarkOn) AppConfig.watermarkText else ""
        val spec = ProjectSpec(clips, if (AppConfig.has("text")) texts else emptyList(), if (AppConfig.has("music")) music else null, if (AppConfig.has("music")) voice else null, if (AppConfig.has("ratio")) ratio else Ratio.ORIGINAL, quality, wm)
        exporter.start(
            spec,
            onProgress = { p -> exportState = ExportState.Running(p) },
            onDone = { result ->
                result.onSuccess { file ->
                    viewModelScope.launch {
                        val uri = withContext(Dispatchers.IO) { exporter.saveToMovies(file) }
                        exportState = if (uri != null) ExportState.Done(uri) else ExportState.Failed("The video was made but could not be saved to your Movies folder.")
                    }
                }
                result.onFailure { e ->
                    exportState = ExportState.Failed("Export failed: " + (e.message ?: e.javaClass.simpleName))
                }
            }
        )
    }

    fun cancelExport() { exporter.cancel(); exportState = ExportState.Idle }
    fun resetExport() { exportState = ExportState.Idle }

    fun newProject() {
        exporter.cancel()
        stopRecording(); saveProject(); projectId = null; clearHistory(); clips = emptyList(); texts = emptyList(); music = null; voice = null; selectedId = null; playhead = 0; ratio = Ratio.ORIGINAL; exportState = ExportState.Idle
    }

    // ───── saved projects ─────

    fun refreshProjects() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            projects = withContext(Dispatchers.IO) { ProjectStore.list(ctx) }
        }
    }

    fun saveProject() {
        if (clips.isEmpty()) return
        val id = projectId ?: System.currentTimeMillis().also { projectId = it }
        ProjectStore.save(getApplication<Application>(), SavedProject(id, clips, texts, music, voice, ratio, quality))
    }

    fun openProject(info: ProjectInfo) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val p = withContext(Dispatchers.IO) {
                val sp = ProjectStore.load(ctx, info.id) ?: return@withContext null
                // keep only clips that can still be opened
                val ok = sp.clips.filter { readable(ctx, it) }
                SavedProject(sp.id, ok, sp.texts, sp.music, sp.voice, sp.ratio, sp.quality)
            }
            if (p == null || p.clips.isEmpty()) { toast("This project could not be opened. Its videos may have been moved or deleted."); return@launch }
            projectId = p.id
            clearHistory()
            nextId = maxOf(p.clips.maxOf { it.id }, p.texts.maxOfOrNull { it.id } ?: 0L) + 1
            texts = p.texts; music = p.music; voice = p.voice; ratio = p.ratio
            quality = minOf(p.quality, AppConfig.quality)
            exportState = ExportState.Idle
            playhead = 0
            clips = p.clips
            selectedId = p.clips.first().id
        }
    }

    private fun readable(ctx: Context, c: Clip): Boolean {
        if (c.isImage) return try { ctx.contentResolver.openInputStream(c.uri)?.use { true } ?: false } catch (e: Exception) { false }
        val uri = c.uri
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(ctx, uri); true } catch (e: Exception) { false } finally { try { r.release() } catch (e: Exception) { /* ignore */ } }
    }

    fun deleteProject(id: Long) {
        ProjectStore.delete(getApplication<Application>(), id)
        refreshProjects()
    }

    // ───── voice-over ─────

    fun startRecording(): Boolean {
        if (recording) return true
        return try {
            val ctx = getApplication<Application>()
            val f = File(ctx.filesDir, "voice_" + System.currentTimeMillis() + ".m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r; recFile = f; recStart = System.currentTimeMillis(); recording = true
            true
        } catch (e: Exception) {
            recorder = null; recording = false
            toast("The microphone could not be started.")
            false
        }
    }

    fun stopRecording() {
        val r = recorder ?: return
        val f = recFile
        recorder = null; recording = false
        try { r.stop() } catch (e: Exception) { f?.delete(); toast("The recording was too short."); try { r.release() } catch (x: Exception) { /* ignore */ }; return }
        try { r.release() } catch (e: Exception) { /* ignore */ }
        val ms = System.currentTimeMillis() - recStart
        if (f != null && ms > 500) {
            voice?.let { old -> try { File(old.uri.path ?: "").delete() } catch (e: Exception) { /* ignore */ } }
            voice = MusicTrack(Uri.fromFile(f), ms, "Voice-over")
        } else f?.delete()
    }
}
