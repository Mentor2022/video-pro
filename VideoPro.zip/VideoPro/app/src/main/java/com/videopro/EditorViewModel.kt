package com.videopro

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    var clips by mutableStateOf<List<Clip>>(emptyList())
    var selectedId by mutableStateOf<Long?>(null)
    var texts by mutableStateOf<List<TextItem>>(emptyList())
    var music by mutableStateOf<MusicTrack?>(null)
    var ratio by mutableStateOf(Ratio.ORIGINAL)
    var quality by mutableStateOf(minOf(AppConfig.quality, 1080))
    var playhead by mutableStateOf(0L)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)

    private var nextId = 1L
    private val exporter = Exporter(app)

    val totalMs: Long get() = clips.sumOf { it.effectiveMs }
    val selected: Clip? get() = clips.firstOrNull { it.id == selectedId }

    private fun toast(msg: String) {
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_LONG).show()
    }

    /** Reads length and size of a video. Returns null when the file cannot be used. */
    private fun readClip(ctx: Context, uri: Uri): Clip? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur < 500 || w <= 0 || h <= 0) null else Clip(id = nextId++, uri = uri, durationMs = dur, displayW = w, displayH = h)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { /* ignore */ }
        }
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { readClip(ctx, it) } }
            if (loaded.size < uris.size) toast("Some files could not be opened as videos.")
            if (loaded.isNotEmpty()) {
                clips = clips + loaded
                if (selectedId == null) selectedId = loaded.first().id
            }
        }
    }

    fun update(id: Long, change: (Clip) -> Clip) {
        clips = clips.map { if (it.id == id) change(it) else it }
    }

    fun delete(id: Long) {
        val i = clips.indexOfFirst { it.id == id }
        clips = clips.filter { it.id != id }
        selectedId = clips.getOrNull(minOf(i, clips.size - 1).coerceAtLeast(0))?.id
    }

    fun move(id: Long, delta: Int) {
        val i = clips.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= clips.size) return
        val l = clips.toMutableList()
        val c = l.removeAt(i)
        l.add(j, c)
        clips = l
    }

    /** Cuts the clip under the playhead in two. */
    fun split(projectMs: Long) {
        var acc = 0L
        for (c in clips) {
            val len = c.effectiveMs
            if (projectMs < acc + len) {
                val at = c.startMs + ((projectMs - acc) * c.speed).toLong()
                if (at - c.startMs < 300 || c.endMs - at < 300) { toast("Move the playhead to the middle of a clip to split it."); return }
                val a = c.copy(endMs = at)
                val b = c.copy(id = nextId++, startMs = at)
                clips = clips.flatMap { if (it.id == c.id) listOf(a, b) else listOf(it) }
                selectedId = b.id
                return
            }
            acc += len
        }
    }

    fun addText(text: String, atMs: Long) {
        if (text.isBlank()) return
        val total = totalMs
        val end = minOf(total, atMs + 3000)
        texts = texts + TextItem(id = nextId++, text = text.trim().take(80), startMs = atMs.coerceAtMost((total - 500).coerceAtLeast(0)), endMs = end.coerceAtLeast(500))
    }

    fun updateText(id: Long, change: (TextItem) -> TextItem) { texts = texts.map { if (it.id == id) change(it) else it } }
    fun removeText(id: Long) { texts = texts.filter { it.id != id } }

    fun setMusic(uri: Uri) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val track = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    var name = "Music"
                    try {
                        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) name = c.getString(0) ?: name
                        }
                    } catch (e: Exception) { /* keep the default name */ }
                    if (dur > 500) MusicTrack(uri, dur, name) else null
                } catch (e: Exception) {
                    null
                } finally {
                    try { r.release() } catch (e: Exception) { /* ignore */ }
                }
            }
            if (track == null) toast("That file could not be used as music.") else music = track
        }
    }

    fun thumbnail(uri: Uri, atMs: Long): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            val b = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val s = 220f / maxOf(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { /* ignore */ }
        }
    }

    fun export() {
        if (clips.isEmpty() || exportState is ExportState.Running) return
        exportState = ExportState.Running(0)
        val wm = if (AppConfig.watermarkOn) AppConfig.watermarkText else ""
        val spec = ProjectSpec(clips, if (AppConfig.has("text")) texts else emptyList(), if (AppConfig.has("music")) music else null, if (AppConfig.has("ratio")) ratio else Ratio.ORIGINAL, quality, wm)
        exporter.start(
            spec,
            onProgress = { p -> exportState = ExportState.Running(p) },
            onDone = { result ->
                result.onSuccess { file ->
                    viewModelScope.launch {
                        val uri = withContext(Dispatchers.IO) { exporter.saveToMovies(file) }
                        exportState = if (uri != null) ExportState.Done(uri) else ExportState.Failed("The video was made but could not be saved to your Movies folder.")
                    }
                }
                result.onFailure { e ->
                    exportState = ExportState.Failed("Export failed: " + (e.message ?: e.javaClass.simpleName))
                }
            }
        )
    }

    fun cancelExport() { exporter.cancel(); exportState = ExportState.Idle }
    fun resetExport() { exportState = ExportState.Idle }

    fun newProject() {
        exporter.cancel()
        clips = emptyList(); texts = emptyList(); music = null; selectedId = null; playhead = 0; ratio = Ratio.ORIGINAL; exportState = ExportState.Idle
    }
}
