package com.videopro

import android.content.Context
import org.json.JSONObject

/**
 * Settings chosen by the admin in the portal. The build writes them to assets/config.json.
 * Without that file (a plain build), everything is on.
 */
object AppConfig {
    private val allFeatures = setOf("trim", "speed", "volume", "text", "music", "filters", "rotate", "ratio")

    @Volatile var features: Set<String> = allFeatures
    /** Highest export height: 720 or 1080. */
    @Volatile var quality: Int = 1080
    @Volatile var watermarkOn: Boolean = false
    @Volatile var watermarkText: String = ""

    fun has(feature: String): Boolean = feature in features

    fun load(ctx: Context) {
        try {
            val j = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
            val f = j.optJSONObject("features")
            if (f != null) features = allFeatures.filter { f.optBoolean(it, true) }.toSet()
            quality = if (j.optInt("quality", 1080) == 720) 720 else 1080
            val w = j.optJSONObject("watermark")
            if (w != null) {
                watermarkOn = w.optBoolean("on", false)
                watermarkText = w.optString("text", "").take(40)
            }
        } catch (e: Exception) {
            // no config: keep the defaults
        }
    }
}
